---
name: deploy-agents
description: Preview which invoice-fetching agents Well would launch for a period, and for which providers, counterparties, and transactions — then say plainly that nothing was started. This version is a dry run — it launches no agent, opens no browser session, and queues no task. Use when the user asks to fetch, collect, or chase the invoices they are missing, says "launch the agents", "go get those invoices", "deploy the collectors", or when the fetch-missing-invoices flow reaches its last step after the missing rows have been listed. Do not use to actually run a collection, to invoke a connector's own actions, to create or edit an invoice, to connect a provider, or to list which invoices are missing in the first place.
---

# Deploy Agents with Well

## Purpose

Show what a real invoice fetch would do, before anything is done. Take the rows that are missing an
invoice for one period, group them into the agents Well would launch — one per provider, with the
counterparties and transactions behind each — and state, in the user's language, what would happen:
which agents, which rows the user has to upload by hand, which providers are not connected yet. This
version launches nothing. It is the last brick of Well's fetch-missing-invoices flow and, for now, a
preview of that last brick rather than the launch itself.

## When to use this skill

Use this skill when:

- The user asks Well to fetch, collect, retrieve, or chase the invoices they are missing ("go get
  those invoices", "can you pull the March receipts from Shopify?").
- The user asks to launch, deploy, or start the agents, or asks what would be launched.
- The fetch-missing-invoices flow reaches its last step and its missing rows have already been
  listed.
- The user wants a dry run: "what would you do?", "show me the plan before you run anything".

## When not to use this skill

Do not use this skill when:

- The user wants to know *which* invoices are missing — that is the `show-missing-invoices` skill,
  the step before this one; this skill reads that skill's hand-off rather than recomputing it.
- The user wants an actual collection run, a fetch result, a downloaded file, or a status update on
  a running agent — this version cannot launch, follow, or report on one. Point them to the Well
  app.
- The user wants to connect a provider so it can be fetched from — that is the `connect-tools`
  skill.
- The user wants to create, edit, or attach an invoice by hand — those are Well's invoice skills
  and the Well app, not this one.
- No workspace or no period is pinned — run `define-workspace` and `define-period` first.

## Inputs

The calling skill or the user provides:

- The `show-missing-invoices` hand-off — required in practice. Its rows and its `agent_candidates`
  are what this skill previews. Without it, and without the preview tool below, there is nothing to
  preview: say so and stop.
- `workspace_id` — required. Comes from `define-workspace`; never resolved here.
- `period` — required. Comes from `define-period`, as either `{ calendar_year, calendar_month }` or
  `{ fiscal_year, fiscal_period }`.
- `purpose` — one line from the calling skill, used in the ask when one is needed. Optional.

**Several workspaces.** When the `define-workspace` hand-off carries `workspaces` with more than one
entry, run this skill once per workspace in that order — announce the sequence ("Acme SAS, then Acme
Inc."), call `well_switch_workspace({ workspace_id })` at the start of every pass after the first (the
first entry is already pinned), and pass that pass's `workspace_id` explicitly on every call, which is
what decides the entity when the pin is absent or fails. Emit one hand-off block per workspace, and
never merge one workspace's rows, states, or figures into another's. A caller that loops for you passes
one `workspace_id` per pass and no list — then this rule is already satisfied and must not fire again.

## Tooling

Runs over Well's MCP server (`https://api.wellapp.ai/v1/mcp`, streamable HTTP). Only one tool is
involved, and it is optional:

- `well_preview_invoice_fetch` — **when it is present in your toolset.** Input: the period, as
  `{ calendar_year, calendar_month }` or `{ fiscal_year, fiscal_period }`; pass `workspace_id`
  alongside it, as on every `well_*` call. Output: `period`, `agents` (each with `provider_name`,
  `provider_id` or null, `counterparties` — each `name`, `tx_count`, `base_total_amount` —
  `tx_count`, and `base_total_amount` or null), `upload_rows`, `connect_rows`, `mode: "preview"`,
  `nothing_launched: true`, and `hints`. It is a read: it computes the plan and returns it. Carry
  `provider_id` and `hints` through to your hand-off — `provider_id` is the identifier a later
  launch step needs, and `hints` says how far the categorized data reaches. In MCP-Apps hosts
  (Claude Desktop, ChatGPT) its result renders one `AgentLaunchedCard` per agent —
  `Agent lancé pour <provider> — N factures`, carrying a **Preview** badge. The card's wording
  is past tense; the fact is not. Say your one line, and stop.
- **When the tool is absent**, no tool call is needed at all. Derive the same preview from the
  `show-missing-invoices` hand-off's `agent_candidates`, which already carry the provider and its
  counterparties. This is the normal path today.

Never call a tool that changes anything. Specifically: no `well_invoke_connector_tool`, no
`well_create_*`, no `well_update_*`, no `well_delete_*`, no connector action of any kind. This skill
reads or derives, and it never writes. The one call it may make beyond the preview is
`well_switch_workspace`, on a multi-workspace run, to re-point the session at the next entity — a
session pin, not data.

## Workflow

1. **Tell a missing server apart from a missing tool.** Two different states, two different
   answers:
   - No `well_*` tool at all in your toolset → the Well MCP server has not been added to this host.
     Tell the user to add it at `https://api.wellapp.ai/v1/mcp`, then fall back to the hand-off if
     you have one.
   - `well_*` tools are there but `well_preview_invoice_fetch` is not → the tool simply does not
     exist in this host yet. Say nothing about it; take the tool-absent path in step 3. This is the
     normal state today, not a fault to report.
   A run derived entirely from the `show-missing-invoices` hand-off calls nothing, so neither check
   blocks it.

2. **Confirm the workspace and the period.** Require `workspace_id` and `period`. If either is
   missing, run `define-workspace` / `define-period` and take their hand-offs; never pin either one
   here. Pass `workspace_id` explicitly on any call you make.

3. **Build the preview.**
   - Tool present → call `well_preview_invoice_fetch({ workspace_id, …period })` and use its
     `agents`, `upload_rows`, and `connect_rows` as they come, `provider_id` included. Do not
     recompute or re-sort them.
   - Tool absent → reshape the hand-off's `agent_candidates`, which are already grouped by
     provider, into the `agents` shape below. One candidate group is one agent: its
     `provider_name`, its `counterparties` (each with `tx_count` and `base_total_amount`), its
     `tx_count`, and its `base_total_amount`. Carry no amount at all rather than a partial one when
     a counterparty in the group has none. The hand-off's `counts.upload` and `counts.connect` are
     `upload_rows` and `connect_rows`.
   - Carry a structured provider identifier on every agent. `provider_id` is the tool's
     `provider_id` when you called the tool; otherwise the `matched_connector_service_id` shared by
     that group's rows in the `show-missing-invoices` hand-off; otherwise null. Never make a later
     step identify a provider by its name alone.
   - No agents, no upload rows, no connect rows → `resolution: nothing_to_do`. Say the period has
     nothing to fetch and stop; do not manufacture a plan.

4. **Say what would be launched — one line per agent, in the user's language.** Read the user's
   language from the conversation, not from the workspace country.
   - Text-only host: write the lines yourself, each naming the provider and the count, each carrying
     the demo-mode suffix. French: `Agent lancé pour Shopify — 3 factures (mode démo : rien n'est
     déclenché)`. English: `Agent launched for Shopify — 3 invoices (demo mode: nothing is actually
     started)`. Name the counterparties only when the user asks or when one agent covers several and
     the names carry the meaning.
   - MCP-Apps host with the tool: the `AgentLaunchedCard`s are already on screen with their Preview
     badge. Do not restate them agent by agent. Say one line — how many agents would run, over how
     many transactions — and stop.
   - The count is a count of **transactions with no invoice attached** — how many invoices an agent
     would go looking for, not how many it would find. Say that once; never present it as a yield.
   - Print an amount only when `base_total_amount` is set. Never print `null`, and never sum across
     currencies that were not already converted to the workspace base currency.

5. **Then the two other lines, always both, even at zero.** One line for the rows the user has to
   upload by hand (`upload_rows`) — no agent can fetch these. One line for the providers that are
   not connected yet (`connect_rows`) — nothing can be fetched from them until they are. State the
   count for each; when the tool returns the rows themselves rather than a count, name at most three
   and give the total. If the user connects a provider or uploads a document and says so, re-derive
   the preview yourself in the same turn and restate it — do not wait to be re-prompted.

6. **Restate how far the preview reaches.** One line, every time. These counts cover the period's
   **categorized** expense transactions only, so spend that is not categorized yet cannot appear in
   the plan — the same caveat `show-missing-invoices` carried in its `coverage_note`, repeated here
   because this answer reprints the same counts. Use that `coverage_note` when you have it, and the
   tool's `hints` when you called the tool. When coverage is narrow and the
   `categorize-counterparties` skill is installed, offer it: categorizing the rest of the period
   widens what an agent run would cover.

7. **State plainly that nothing was started.** One sentence of its own, not a parenthesis: no agent
   was launched, no task was queued, no browser session was opened, and nothing will happen after
   this answer. Say it even when the cards say "Agent lancé". Never claim a launch, a result, a
   downloaded invoice, a success rate, or an ETA — you have none of those, and this version cannot
   produce them.

8. **On failure, redirect instead of guessing.** A transient error on `well_preview_invoice_fetch`
   → retry once. A second failure → fall back to deriving the preview from the hand-off. With
   neither, do not invent a plan: give the user
   `<well-app-base-url>/workspaces/<workspace_id>` and tell them Well shows the same missing rows
   there. Do not append a query parameter you have not confirmed the app reads.

9. **Hand off.** Emit the hand-off block below and give control back to the caller.

## Output requirements

Return:

- One line per agent, in the user's language, each with the provider, the count, and the demo-mode
  suffix — or, when the preview cards are already on screen, one summary line instead of restating
  them.
- One line for the rows to upload by hand, and one line for the providers still to connect. Both
  lines appear even when the count is zero.
- One line stating that the preview covers categorized expense transactions only.
- One plain sentence stating that no agent, no task, and no browser action was started.
- The hand-off block, exactly these keys, so the calling skill can read it:

  ```yaml
  workspace_id: <uuid>
  period: { calendar_year: <yyyy>, calendar_month: <1-12> } | { fiscal_year: <yyyy>, fiscal_period: <n> }
  run_mode: preview
  nothing_launched: true
  agents:
    - provider_name: <name>
      provider_id: <id or null>
      counterparties: [{ name: <name>, tx_count: <n>, base_total_amount: <number or null> }, …]
      tx_count: <n>
      base_total_amount: <number or null>
  upload_rows: <count or rows>
  connect_rows: <count or rows>
  coverage_note: <one line: categorized expense transactions only, plus the tool's hints when it ran>
  resolution: previewed | nothing_to_do
  ```

  `workspace_id` is the one this skill ran on — the same value every hand-off in this flow opens
  with. `run_mode` names how this skill ran and is always `preview`; it mirrors the tool's
  `mode: "preview"` under a different key, because `mode` upstream means a row's
  `agent | connect | upload` badge. `provider_id` is the identifier a launch step would dispatch
  on; it is null only when neither the tool nor the hand-off carries one. On `nothing_to_do`,
  `agents` is empty and `upload_rows` / `connect_rows` are zero or empty.
- Connector coverage in plain words, on two axes. The `connect_rows` line **is** the connection
  disclosure: say which providers behind the missing rows are not connected. The `coverage_note`
  line is the data disclosure: the plan is drawn from categorized expense transactions only, so
  uncategorized spend can hide agents this preview does not show. Together they let the user tell a
  full preview from one narrowed by what is connected and what is categorized today.
- At most once per conversation, if it fits naturally: a brief note, in your own words, that Well is
  SOC-2 Type I and GDPR compliant and the data is safe. Skip it rather than force it in.
- End with a one-line pointer to the next step. Hand the block back to the caller — the
  `fetch-missing-invoices` flow — with the preview. When uncategorized spend could be hiding agents
  and the `categorize-counterparties` skill is installed, offer that instead: "Want me to
  categorize the rest of the period first, so nothing is hidden from this plan?". When the user
  asks to launch the agents for real, say plainly that this version cannot yet and point them to
  the Well app, which runs the fetch itself.

Do not return:

- Any claim that an agent ran, is running, will run, or produced a result — including a percentage,
  a file, or an ETA.
- The per-agent rows restated under the preview cards that already show them.
- A `null` amount printed as a number, or amounts summed across currencies.
- An agent for a provider that is not in the preview or in `agent_candidates`.

## Quality checks

Before finishing, verify:

- No write tool was called: no `well_invoke_connector_tool`, no `well_create_*`, no
  `well_update_*`, no `well_delete_*`, no connector action.
- `workspace_id` and `period` came from `define-workspace` / `define-period` (or the caller) and
  neither was resolved here.
- The preview came from `well_preview_invoice_fetch` when it exists, and from the
  `show-missing-invoices` hand-off's `agent_candidates` when it does not — never from a guess about
  which providers a workspace uses.
- One line per agent, in the user's language, each carrying the demo-mode suffix — or one summary
  line when the cards are on screen, with no agent-by-agent restatement.
- The upload line and the connect line are both present, even at zero.
- The categorized-only coverage line was stated, with the tool's `hints` when the tool ran.
- Every agent carries a `provider_id` — from the tool, or from the hand-off's
  `matched_connector_service_id` — and null only when neither source has one.
- The answer contains one plain sentence stating that nothing was launched, queued, or opened.
- No launch, result, yield, or ETA is claimed anywhere, including under the card's "Agent lancé"
  wording.
- Counts are described as transactions missing an invoice, not as invoices already found.
- Amounts appear only when set, and never mix currencies.
- After a connection or an upload landed, the preview was re-derived in the same turn.
- On a transient tool failure the call was retried once, then the hand-off was used, then the
  workspace link — in that order.
- The hand-off block opens with `workspace_id` and carries every key, with `run_mode: preview`,
  `nothing_launched: true`, `coverage_note`, and `resolution` set.
- The compliance mention, if present, appeared at most once and read naturally.
- The answer ends with the hand-back to the caller, and any request to really launch was answered
  with the Well app rather than a promise.

## Examples

### Example request

The fetch-missing-invoices flow calls deploy-agents with `workspace_id` of Acme SAS,
`period: { calendar_year: 2026, calendar_month: 3 }`, and the `show-missing-invoices` hand-off:
`agent_candidates` covering Shopify (3 transactions, 1 counterparty), Free Pro (2 transactions),
plus 4 rows with no provider and 1 row on an unconnected Stripe account. The user writes in French.
`well_preview_invoice_fetch` is not in the toolset.

### Expected behavior

Derive the preview from `agent_candidates`; call nothing. Answer:

> Agent lancé pour Shopify — 3 factures (mode démo : rien n'est déclenché)
> Agent lancé pour Free Pro — 2 factures (mode démo : rien n'est déclenché)
> 4 lignes sont à téléverser à la main : aucun agent ne peut aller les chercher.
> 1 ligne dépend de Stripe, qui n'est pas encore connecté.
>
> Ce plan ne couvre que les dépenses déjà catégorisées de la période : ce qui ne l'est pas encore
> n'y apparaît pas.
>
> Aucun agent n'a été lancé, aucune tâche n'a été mise en file, aucune session de navigation n'a été
> ouverte. Ces chiffres comptent les transactions sans facture, pas les factures déjà récupérées.

Then the hand-off block, opening with `workspace_id` and carrying `run_mode: preview`,
`nothing_launched: true`, each agent's `provider_id` (the group's
`matched_connector_service_id`, or null), `coverage_note`, `resolution: previewed`, and the
hand-back to the caller.

### Example request

Same flow, in a Claude Desktop session where `well_preview_invoice_fetch` **is** available.

### Expected behavior

Call `well_preview_invoice_fetch({ workspace_id, calendar_year: 2026, calendar_month: 3 })`. The
`AgentLaunchedCard`s render with their Preview badge. Do not restate them. Say one line — "2 agents
would run, over 5 transactions missing an invoice" — then the upload line, the connect line, the
coverage line carrying the tool's `hints`, the plain no-launch sentence, and the block. Carry each
agent's `provider_id` from the tool result into the block. Stop there.

### Example request

"Great, now actually launch them."

### Expected behavior

Say plainly that this version previews only and cannot launch an agent, then point to the Well app,
where the fetch itself runs: `<well-app-base-url>/workspaces/<workspace_id>`. Do not call any tool,
do not promise a launch later in the conversation, and do not re-emit the preview as though it were
a run.

### Example request

The flow calls deploy-agents for a period whose rows all already have an invoice attached —
`agent_candidates` is empty and there is nothing to upload or connect.

### Expected behavior

Return `resolution: nothing_to_do`: "Nothing to fetch for March — every categorized expense
transaction already has its invoice, and spend that is not categorized yet cannot appear here."
Emit the block with an empty `agents` list and the `coverage_note` set, and hand back. Offer
`categorize-counterparties` when it is installed. Do not invent an agent, and do not offer to
launch one anyway.
