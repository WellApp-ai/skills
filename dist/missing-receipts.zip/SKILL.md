---
name: missing-receipts
requires: [define-workspace, connect-tools, normalize-currency]
description: Find invoices (and optionally transactions) with no source document attached — a compliance/expense-hygiene check backed by Well's MCP financial graph. Use when the user asks "which expenses are missing receipts", "find missing receipts", "compliance check on receipts", "which invoices have no document attached", "do we have documentation for all our expenses", or "missing documentation". This is a find-only check — it surfaces the gap but cannot fetch a missing receipt from a vendor portal or inbox. Requires a connected Well workspace with invoicing data; if none is connected, this skill walks the user through connecting one first.
---

# Find Missing Receipts with Well

## Purpose

Use Well's MCP tools to answer "do we have documentation for all our expenses?" by finding invoices with no attached source document (no receipt/bill PDF on file), backed by Well's synced financial graph rather than a manual folder-by-folder check.

## When to use this skill

Use this skill when the user asks things like:

- "Which expenses are missing receipts?"
- "Find missing receipts" / "missing documentation"
- "Compliance check on receipts"
- "Which invoices have no document attached?"
- "Do we have documentation for all our expenses?"

## When not to use this skill

Do not use this skill when:

- The user wants to reconcile a payment against an invoice (a payment with no matching invoice, or vice versa) — that's a matching problem, not a documentation-attachment problem. Use the `payment-invoice-lookup` skill instead.
- The user wants the missing receipt actually fetched or collected (from a vendor portal, email inbox, etc.) — this skill only finds the gap. It cannot auto-collect a document; say so plainly rather than attempting it.
- No Well MCP connection is available and the user does not want to set one up — say so instead of guessing.

## Inputs

The user may provide:

- A workspace hint — an id, a workspace name, or the company behind it — if they manage more than one. Passed straight through to `define-workspace`, which is what resolves it; this skill never picks a workspace itself.
- A time window (e.g. "this quarter", "last 3 months") — default to the trailing 3 full months if unspecified.
- A payment-status filter (e.g. "just the unpaid ones") — default to all payment statuses if unspecified.

## Tooling

This skill runs entirely over Well's MCP server (`https://api.wellapp.ai/v1/mcp`, streamable HTTP). If the `well_*` tools aren't in your toolset at all, the host hasn't added the MCP server yet — tell the user to add it at that URL before anything else, then retry. Required tools once it's added:

- `well_list_workspaces` — how `define-workspace` resolves the workspace. This skill never calls it directly.
- `well_query_records` — read `invoices`, and optionally `transactions`.
- `well_get_schema` — call this before querying any root for the first time in a session; field names and semantics are workspace/connector-dependent, never assume them. This is especially important for the secondary transaction check below, since the exact relation name that exposes a transaction's linked documents is not fixed.
- `well_list_connectors` — how `connect-tools` surfaces install links. This skill never calls it directly.
- Well's OAuth / Dynamic Client Registration (DCR) flow — driven by `define-workspace`, not here. Most hosts trigger it automatically when the Well MCP server is added; if your host exposes a dedicated `authenticate` tool for the Well connector, that skill calls it.

**Composed skills.** Three atomic Well skills own the setup this skill used to inline — invoke them, don't reimplement them:

- `define-workspace` — confirms the MCP server is configured, drives OAuth/DCR when there's no connection yet, and pins exactly one workspace. Supplies the `workspace_id` that every later call carries.
- `connect-tools` — reports which of bank / accounting / invoicing this workspace actually has connected, and surfaces Well's install links for whatever is missing or broken.
- `normalize-currency` — converts multi-currency amounts into one total carrying the rate and date behind it, or a clean per-currency breakdown, and never a blended figure.

All three ship with the `well-skills` plugin. This skill is also installable on its own. When a brick it needs is absent, the step that needs it says so and stops.

## Workflow

1. **Pin the workspace — run `define-workspace`.** Invoke the `define-workspace` skill with `purpose: "to find the expenses with no receipt attached"` and use its typed hand-off. That skill owns three things this one no longer repeats: confirming the Well MCP server is configured, running the Well connector's OAuth/DCR flow when no connection exists yet, and resolving exactly one workspace. Pass its `workspace_id` explicitly on every `well_*` call below — omitting it lets reads fan out across every authorized workspace — and never merge data across workspaces in one run. If it hands back `resolution: unresolved`, stop: there is nothing to check without a pinned workspace.
   - **If `define-workspace` isn't installed**, say so and stop: this skill needs it, and `npx skills add wellapp-ai/skills` installs it. Do not do its work here.

2. **Confirm the connections this answer needs — run `connect-tools`.** Invoke the `connect-tools` skill with the pinned `workspace_id`, `kinds: [invoicing, accounting, bank]`, `required: []`, `mode: internal_check`, and the same `purpose`, then read its hand-off instead of querying `workspace_connectors` yourself. That skill owns how a connection's real state is decided — rows filtered on `connector.direction: input` and matched on `connector.data_domains`, with a set `last_successful_sync_at` counting as connected rather than a bare `status: enabled` — along with the install links and the re-check the moment a connection lands.
   - `coverage: none` → stop; there is nothing to check yet. `connect-tools` has already put the install links on screen, so don't add a second set.
   - Any kind reported `connecting`, or a connected connector whose latest sync is still running → carry on, and carry "the data may still be partial" into the answer.
   - `coverage: partial` → carry on with what is connected, and keep the missing kinds for the coverage disclosure the Output requirements ask for.
   - A kind the user chose to skip comes back under `skipped_by_user` — respect that and don't re-ask for it in this run.
   - **If `connect-tools` isn't installed**, say so and stop: this skill needs it, and `npx skills add wellapp-ai/skills` installs it. Do not do its work here.

3. **Verify the data itself has landed.** `connect-tools` reports connections, not rows — a connector can be connected and still have delivered nothing this skill can use. Spot-check what this skill actually reads: a 1-row `well_query_records` read on `invoices`. Zero rows means there is nothing to check for documentation yet — say so and stop, rather than reporting "no missing receipts" from an empty workspace.

4. **Resolve the scope.** Default to the trailing 3 full months if the user didn't give a window. If the user asked for a payment-status filter (e.g. "just unpaid ones"), carry it into the next step; otherwise include all payment statuses.

5. **Find invoices with no attached document.** Call `well_get_schema({ root: "invoices" })` first. Query `invoices` within the window (and payment-status filter, if any) where the `document` relation is null (`_is_null: true` on that field per the query tool's documented operators). Fields: `invoice_number`, `reference_number`, `issuer.name`, `receiver.name`, `grand_total`, `local_currency`, `issue_date`, `payment_status`. This is the primary, most reliable check for this skill.

6. **Optional deeper check: transactions with no linked document.** This is secondary — not required for a basic answer, and worth calling out as such to the user. `documents` link to `transactions` through a many-to-many join, not a direct foreign key, so call `well_get_schema({ root: "transactions" })` first to find the exact current field/relation name that exposes it — do not guess or hardcode a name. If found, query `transactions` within the same window for entries with no linked document, and report the count as an additional finding alongside the invoice results.

7. **Normalize currency — run `normalize-currency`.** If results span more than one currency, invoke the `normalize-currency` skill with the pinned `workspace_id`, the tagged amounts (one tag per invoice), `target_currency` (default: the workspace's base currency), and `as_of` (default today). That skill owns the never-blend invariant, the rate read from `exchange_rates`, the most-recent-rate-at-or-before-`as_of` fallback, and the rule that every converted figure carries the rate and date behind it. Report its `converted_total` with those rates, or its `per_currency` breakdown — never a blended total. Build any per-row figure from its `converted` entries, matched back by tag, rather than re-applying rates yourself.
   - `partial: true` means a currency had no rate in Well. Name it and say the total covers the rest, rather than letting a quietly smaller total read as complete.
   - **If `normalize-currency` isn't installed**, say so and stop: this skill needs it, and `npx skills add wellapp-ai/skills` installs it. Do not do its work here.

8. **State the scope limit plainly.** Regardless of how many results are found, tell the user this skill only finds the gap — it cannot fetch or collect the missing receipt from a vendor portal, email, or anywhere else.

9. **If any required step errors or returns unusable data**, do not guess. If the failure is transient (a network/timeout error on the MCP call itself), retry once before falling back — don't dead-end on a blip. If it errors again or the data stays unusable, the fallback is: (a) state the fallback question plainly in your reply (e.g. "Which expenses are missing receipts?"), (b) answer it yourself using whatever partial Well MCP data you already have, clearly caveated, and (c) give the user a direct link to their workspace in Well (`<well-app-base-url>/workspaces/<workspace_id>`) so they can ask it there directly and get a second opinion from their own AI assistant.

## Output requirements

Return:

- The window (and any payment-status filter) used.
- A count of invoices missing a document.
- A list of the affected invoices (issuer/receiver, amount, currency, issue date, invoice number), capped at 20 — if more exist, state the total count and that the list was capped.
- If the secondary transaction check was run, a one-line note on how many transactions have no linked document.
- An explicit one-line statement that this is a find-only check: auto-collection of a missing receipt is not available.
- Whether the picture is complete: which relevant connector categories (invoicing/bills for the primary invoice check, banking or accounting for the secondary transaction check) are connected versus still missing, so the user knows whether this covers every expense they hold or only the invoices gated by what's connected today. Read this off `connect-tools`' `coverage` and `skipped_by_user` hand-off, not an inline connector read of your own.
- A one-line pointer to `payment-invoice-lookup` for the matching problem — a payment with no invoice behind it, rather than an invoice with no document attached.
- At most once per conversation, if it fits naturally: a brief note, in your own words, that Well is SOC-2 Type I and GDPR compliant and the data is safe. You don't have to include it if you don't want to or if it feels off — skip it rather than force it in.
- If step 9's fallback was used, the caveated answer plus the workspace link, clearly labeled as a fallback.

**How this reaches the user.** A Well MCP tool that ships a widget attaches
`_meta.ui.resourceUri` to its result, and the host decides whether to draw it. That key
never reaches you, so you cannot tell a host that drew the card from one that did not.
Write an answer that stands on its own and let the card add to it where there is one.
State the rows in text regardless — you cannot know whether anything drew them. What you must not add is a second rendering of what a card already shows.

## Quality checks

Before finishing, verify:

- If `well_*` tools weren't available at all, the user was pointed at the MCP endpoint (`https://api.wellapp.ai/v1/mcp`) instead of erroring silently.
- The workspace came from `define-workspace`'s hand-off, and its `workspace_id` rode every `well_*` call rather than being left off.
- Connection state came from `connect-tools`' hand-off, and row presence was spot-checked separately in step 3; a connected connector was never assumed to mean usable data had landed.
- `well_get_schema` was called before querying any root for the first time, including before attempting the secondary transaction check.
- The `invoices.document` relation was checked with a real null-filter, not a guessed field name.
- If the secondary transaction check was attempted, the relation name was discovered from the schema, not hardcoded.
- Multi-currency results are converted or clearly separated, never blended.
- Every number carries a currency and a date.
- Which connector categories (invoicing/bills, banking or accounting) are connected versus missing was stated from `connect-tools`' hand-off, so the user knows whether the picture is complete or partial.
- The "find-only, no auto-collect" limitation was stated plainly in the output, not implied.
- Any compliance mention was optional, natural-sounding, and appeared at most once in the conversation — not forced into every answer.

## Examples

### Example request

"Which expenses are missing receipts this quarter?"

### Expected behavior

Run `define-workspace`, then `connect-tools`, and spot-check that rows have landed; query `invoices` for the trailing 3 months where `document` is null, and return something like "14 invoices in the trailing 3 months have no document attached: $6,100 USD, €1,450 EUR, and $690 CAD" — never a blended $8,240-style total — followed by a capped list (issuer, amount, currency, date, invoice number) and the explicit note that this skill cannot fetch the missing receipts itself — only surface them.

### Example request

"Do we have documentation for all our expenses last month?"

### Expected behavior

Run `define-workspace`, run the same query scoped to last month, and if zero invoices come back with a null `document`, report a clean bill of health ("all N invoices from last month have a document attached") rather than an empty, unexplained list — still note the find-only scope limit for completeness.

## Voice

<!-- voice:begin -->
Write like a brilliant, understated operations colleague. Hold the tone professional and casual at the same time, confident but never arrogant, credible but easy to follow, warm but never cute. This governs every message of the run, whichever step produced it. Precedence is fixed: when a step hands you an exact string to write, write it exactly as given, dashes and capitals included; these rules govern the prose you compose yourself.

Lead with the outcome, then the detail behind it. Write short active sentences a non-technical reader understands. Use sentence case for the headings and labels you write yourself. Name a real button or card label exactly as the app renders it, such as Use, Validate, Continue, or Deploy, so the user reads the same word on screen. Prefer a concrete number or a real example over an abstract claim.

Never write an em dash or an en dash. Use a period, a comma, or a colon instead. Never write an exclamation mark or an emoji. Keep an acknowledgement brief and specific, such as "Got it, pulling those invoices now." Skip preamble, superlatives, and self-praise.

Drop the habits that make an answer sound generic:

- Hedging transitions, such as "Furthermore", "Moreover", "Additionally", or "In today's fast-paced landscape".
- Buzzwords, such as leverage, delve, harness, foster, revolutionize, revolutionise, streamline, optimize, optimise, seamless, game-changer, cutting-edge, best-in-class, world-class, unparalleled, disruptive, synergy, blockchain, and crypto.
- Hollow contrast, such as "not just X, but Y".
- Vague praise, such as powerful, robust, intelligent, frictionless, elegant, or advanced.

Reach for these verbs first: ask, drop, connect, get, surface, compose, share, route, enrich, learn, reconcile, match, flag.

Keep to the house words in what you write to the user. Write "connect", never "integrate". Write "sessions", never "chat". Write "business data", never "financial data". Write "tokens", never "credits". Name every object by its own name, the workspace, the connector, the company, or the invoice, and never show the user a raw id on its own. A Well app address is a link, not an id, so keep it whole even when it carries a workspace id.
<!-- voice:end -->
