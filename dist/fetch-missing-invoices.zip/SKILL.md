---
name: fetch-missing-invoices
description: Walk Well's whole missing-invoice flow end to end — pin the workspace, check the bank / accounting / invoicing connections, get the bank feed in, fix the month, list the settled spend that still has no supplier invoice, raise categorization coverage when the list is thin, and preview which invoice-fetching agents would run. The last step is a dry run and launches nothing. Use when the user says "fetch the invoices I'm missing", "what am I missing for March", "chase my missing supplier invoices before I close the books", "run the missing-invoice flow", or "go get those invoices", or when a flow needs every brick walked in order rather than one at a time. Orchestrates define-workspace, connect-tools, connect-bank, define-period, show-missing-invoices and deploy-agents through their typed hand-offs, plus categorize-counterparties when that brick is installed. Do not use to actually launch a collection, to compute a spend total, to close or post a period, or to run one brick on its own.
---

# Fetch Missing Invoices with Well

## Purpose

Run every brick of Well's missing-invoice flow in one pass, in a fixed order, routing on each
brick's typed hand-off keys rather than on impressions: `define-workspace` → `connect-tools` →
`connect-bank` → `define-period` → `show-missing-invoices` → (`categorize-counterparties`, when its
procedure is available, → `show-missing-invoices` again) → `deploy-agents`. Each brick's full
procedure ships with this skill; when the categorization one is absent, the flow says so rather than
improvising it. Every stop is explicit and named, and the last step previews the invoice-fetching agents without
launching one. When `define-workspace` hands back several entities, the same walk becomes a loop —
one full pass per workspace, re-pinned at the start of each, with their figures kept apart.

## When to use this skill

Use this skill when:

- The user asks Well to find and go after the invoices they are missing ("fetch the invoices I'm
  missing for March", "go get those receipts", "chase my missing supplier invoices").
- The user wants the whole month-end sweep — what is missing, what Well can fetch, what they must
  upload — instead of asking brick by brick, or is preparing a close and wants the gaps closed.

## When not to use this skill

Do not use this skill when:

- The user wants exactly one brick — `define-workspace`, `connect-tools`, `connect-bank`,
  `define-period`, `show-missing-invoices`, `categorize-counterparties`, or `deploy-agents` on its
  own.
- The user wants a collection actually run, a downloaded document, or the status of a running agent.
  No version of this flow launches anything; point them to the Well app.
- The user wants a figure (`expense-breakdown`, `cash-position`, `bills-due`,
  `accounts-receivable-aging`), ledger rows with no attachment (`missing-receipts` — this flow
  starts from settled bank spend), or a period closed, locked, or posted (the Well app).

## Inputs

All optional. Resolve everything else through the bricks; never guess a workspace or a month here.

- A workspace hint — a `workspace_id`, a name, "my FR entity", or several of them ("FR and US", "both
  my companies") — passed straight to `define-workspace`, which decides whether that is one entity or
  a sequence.
- A month hint — "March", "last month", "2026-03" — passed to `define-period`.
- A bank the user named — "Qonto", "my BNP account" — passed to `connect-bank`.
- A `purpose` line, default "to fetch the invoices missing for that month", passed to every brick.

## Tooling

Runs over Well's MCP server (`https://api.wellapp.ai/v1/mcp`, streamable HTTP). **Check first that
`well_*` tools are in your toolset at all.** If none are, this host has not added the Well MCP
server: tell the user to add it at that URL, say the flow cannot start without it, and stop — do not
call an undefined tool and do not estimate anything.

The union of the bricks' tools — each owned by the brick that calls it, never called here to
shortcut a step: `well_list_workspaces`; `well_list_connectors`, which is the ONLY tool the two
connection steps call (never `well_query_records` on `workspace_connectors` — that renders a records
table where the connect card belongs); `well_switch_workspace`, `well_list_periods`,
`well_list_missing_invoices` and `well_preview_invoice_fetch` when present;
`well_list_counterparties` — whose result also carries the company-category catalog — and
`well_update_company` with its `relationships.categories`; `well_get_schema` and
`well_query_records` on `transactions` only (the period-activity probe — never on `categories` or
`workspace_connectors`); and Well's OAuth /
DCR flow when no Well connection exists yet — the moment it returns, retry the failed call in the
same turn, never waiting for the user to confirm they signed in.

Never call `well_invoke_connector_tool`, any `well_create_*` / `well_delete_*`, any `well_update_*`
other than `well_update_company`'s categories relationship, or any close, lock, or posting tool.
This flow reads, and writes only the workspace pin `define-workspace` sets — re-set at the start of
each later pass on a multi-workspace run — and the counterparty categories the user confirmed inside
`categorize-counterparties`.

Each brick's full procedure ships with this skill. At each step, **read its "Step reference" section and
follow it** — do not re-derive its checks here.

## Workflow

Walk the steps in order, passing `workspace_id` explicitly on every `well_*` call from step 2 on.
After each step, take its hand-off — the facts the brick keeps, never printed — and route on the
routing table's exact key before the next. Call each list or read tool once per step: the widget
cards refresh themselves, so never re-call a tool just to check progress.

1. **Workspace** — the "Step reference: define-workspace" section, with the workspace hint and `purpose`. Keep
   `workspace_id` and `identity.fiscal_year_start_month`. On `resolution: multi_picked` the hand-off
   also carries `workspaces` in the user's pick order — read **Several workspaces** below before
   step 2.

2. **Connections** — the "Step reference: connect-tools" section, with `kinds: [bank, accounting, invoicing]`,
   `required: []`, `purpose`. No kind blocks at this step; only `coverage: none` stops it, and only
   until the user answers — the bank gets its own stop at step 3. Keep the missing kinds for the
   recap. A brick that reports it could not read the catalog at all is a failure, not `coverage:
   none`; take it to step 9.

3. **Bank** — the "Step reference: connect-bank" section, with `workspace_id`, `required: false`, `purpose`, and
   any bank the user named. Skip this step only when step 2 already reported `bank` as `connected`.
   The bank has its own step because settled bank spend is what the gap list is measured against;
   `connecting` is enough to continue, `missing` or `error` is a stop until the user answers or
   skips.

4. **Period** — the "Step reference: define-period" section, with `workspace_id`, `fiscal_year_start_month`, the
   month hint, `purpose`. Keep the whole block. `is_complete: false` is not a stop: continue, and
   say the list keeps moving until the month ends.

5. **Gap list** — the "Step reference: show-missing-invoices" section, with `workspace_id` and the period
   hand-off. Keep `counts`, `total_base_amount`, `agent_candidates`, `transaction_count`,
   `coverage_note`. Relay an `unavailable` result, never work around it: the list is not
   approximated from raw transactions, because that measures something else.

6. **Categorization gate — only on a thin list or on request.** Run this step when the user asks to
   categorize, or when the list is **thin**: `transaction_count` is null or 0 while the period's
   `has_activity` is `true`. Never run it silently — say in one line that the gap list rests on
   `transaction_count` categorized transactions while the month has bank activity, ask whether to
   categorize the counterparties behind the rest first, and follow
   the "Step reference: categorize-counterparties" section (with `workspace_id`, `periods` holding the step 4
   month, `purpose`) only on the user's yes, because it writes. Keep `coverage_before`,
   `coverage_after`, and `changed`. When that brick's procedure does not ship with this copy of the
   skill, say the categorization step is not available yet and go to step 8 — never substitute your
   own labelling.

7. **Re-read the gap list, once** — the "Step reference: show-missing-invoices" section again, same `workspace_id`
   and period. Replace the step 5 hand-off and route it as in step 5, except that a second thin
   result never re-enters step 6.

8. **Preview the agents** — the "Step reference: deploy-agents" section, with `workspace_id`, the period, and the
   current `show-missing-invoices` hand-off. Preview-only: one line per agent in the user's language
   — `Agent lancé pour <provider> — N factures (mode démo, rien n'est déclenché)`, or `Agent
   launched for <provider> — N invoices (demo mode, nothing is started)` in English — then the
   upload line and the connect line, both even at zero.

9. **On failure, redirect instead of guessing.** Each brick already retries a transient call once.
   When a brick hands back a failure, do not substitute your own read of the same data and do not
   skip ahead: stop at that step, name it, and give the user
   `<well-app-base-url>/workspaces/<workspace_id>` to continue in Well. Do not append a query
   parameter you have not confirmed the app reads.

### Several workspaces

`resolution: multi_picked` is a sequence, not a wider scope — Well pins one workspace at a time. Run
steps 2 to 8 in full, once per entry of `workspaces`, in that order. The first entry is already
pinned, so pass one opens directly at step 2; every later pass opens with
`well_switch_workspace({ workspace_id })` on its own entry, and passes that entry's `workspace_id`
and its own `fiscal_year_start_month` explicitly on every call below. **Hand each brick that one
`workspace_id`, never the `workspaces` list** — the loop lives here, and a brick that receives the
list loops again inside a pass that is already looping. Resolve the period inside each
pass: a month hint applies to every pass, and a month the user picked belongs to the pass that asked.
Announce the sequence once ("Acme SAS, then Acme Inc."), then recap each entity as its pass ends.
Never merge rows, counts, totals, or coverage across two entities. A stop or a skip inside one pass
ends that pass only — record it in that entity's recap and start the next pass anyway — and step 9's
redirect carries the failing pass's own `workspace_id`.

### Routing table

| after | key | value | action |
|---|---|---|---|
| 1 | `resolution` | `unresolved` | **stop** — say no workspace was pinned and the flow needs one entity before it reads anything; offer to resume on a pick |
| 1 | `resolution` | `single` · `hint_matched` · `user_picked` | continue to 2 |
| 1 | `resolution` | `multi_picked` | run 2→8 once per `workspaces` entry, in order — see **Several workspaces**; every row below applies inside a pass, to that pass alone |
| 2 | `coverage` | `none` | **offer, then stop** — nothing is connected, so there is no settled spend to compare invoices against; surface each missing kind's `install_url`. On a new connection, re-read coverage in the same turn and continue; on "continue anyway", continue and carry the caveat |
| 2 | `coverage` | `partial` · `complete` | continue to 3, and skip 3 when `kinds.bank.state` is `connected` |
| 3 | `state` | `connected` · `connecting` | continue to 4; on `connecting` say the spend may be partial for a few minutes |
| 3 | `state` | `missing` · `error` | **offer, then stop** — the gap list is measured against settled bank spend. On the bank landing, re-read in the same turn and continue; on `skipped_by_user: true`, continue to 4 and label the recap as narrowed by a missing bank feed |
| 3 | `resolution` | `unavailable` | continue to 4 with the bank state unknown, and say so in the recap — never claim a bank is connected or missing on an unread catalog |
| 4 | `resolution` | `unresolved` | **stop** — no month pinned, and the rest of the flow is month-scoped |
| 4 | `resolution` | `single` · `hint_matched` · `user_picked` | continue to 5 |
| 5 / 7 | `resolution` | `unavailable` | **stop** — the Well server this host is connected to does not expose the missing-invoice tool yet; no categorization, no preview |
| 5 / 7 | `resolution` | `empty`, `transaction_count` > 0 | **stop and celebrate** — every categorized expense transaction already has its invoice; recap without a preview |
| 5 | `resolution` | `empty`, `transaction_count` null or 0, `has_activity: true` | thin — nothing was examined; go to 6 |
| 5 | `resolution` | `listed`, thin (with `has_activity: true`) or user asked | go to 6 |
| 5 | `resolution` | `listed`, not thin | skip to 8 |
| 5 | `has_activity` | `false` · `unknown` | the thin test never fires — a list that would otherwise read as thin skips 6 and 7 and goes to 8, saying the month's bank activity could not be confirmed |
| 6 | — | the categorization brick's procedure is absent | go to 8, say the step is unavailable |
| 6 | `resolution` | `updated` | keep `coverage_before` / `coverage_after`; re-read the list at 7 |
| 6 | `resolution` | `unchanged` · `read_only` · `unavailable` | keep the step 5 list, say why coverage did not move — nothing to assign, this server cannot write categories, or it does not expose the counterparty list — and go to 8 |
| 7 | `resolution` | thin again | go to 8, say coverage did not move enough to change the list |
| 8 | `resolution` | `previewed` · `nothing_to_do` | recap; on `nothing_to_do` say the period has nothing to fetch |

## Output requirements

Every brick reports its own step as it runs. Close the run with one recap, in this order — and on
`multi_picked`, one such recap per entity, in `workspaces` order, each opening with that entity's
name, so no line, total, or coverage claim ever spans two of them:

- **Workspace and period** — the pinned workspace with its country and base currency when set, and
  `period_label` with its fiscal coordinate and whether the month is complete.
- **Coverage** — which of bank / accounting / invoicing are connected versus missing, the bank state
  the bank step ended on, and that the gap list covers categorized expense transactions only. Label
  a narrowed picture as narrowed, and say plainly when a skipped or unread bank feed is what
  narrowed it.
- **Missing invoices** — counterparty counts per mode (`agent` / `connect` / `upload`) and the
  base-currency total, over the rows that carry an amount only.
- **Categorization delta** — only when step 6 ran: categorized before → after, and how many changes
  the user confirmed, or one line saying the categorization step was unavailable when its
  procedure is absent.
- **Preview** — the per-agent lines with the demo-mode suffix, or one summary line when the cards
  are already on screen, plus the upload line and the connect line.
- **The no-launch sentence**, on its own: no agent was launched, no task was queued, no browser
  session was opened, and nothing happens after this answer.
- At most once per conversation, if it fits naturally and no brick already said it: a brief note, in
  your own words, that Well is SOC-2 Type I and GDPR compliant and the data is safe. Skip it rather
  than force it in — it is offered, never mandatory.
- End with one line on what is next: connecting the providers behind the `connect` rows turns manual
  uploads into gaps Well can fetch itself (`connect-tools`), and the Well app runs the real fetch.
- The recap and every step's report stay plain sentences a non-technical user understands. Never
  print yaml, JSON, or a fenced code block to the user — the bricks' hand-offs are reasoning state,
  carried forward in the conversation, and the next step re-reads what it needs from its own tool
  calls.

Do not return a yaml, JSON, or fenced code block anywhere, a step's rows restated when its card is
on screen, a total that mixes currencies, a claim that anything was launched or collected, a gap
list, coverage figure, or preview built here instead of by its brick, or — across a multi-workspace
run — one merged table, one combined total, or one recap standing for two entities.

## Quality checks

Before finishing, verify:

- If no `well_*` tool was in the toolset, the user was pointed at `https://api.wellapp.ai/v1/mcp`
  and the flow stopped there.
- Every step ran by reading its "Step reference" section, in order — none skipped or re-implemented
  inline — and each route was decided on the routing table's key.
- The flow stopped, with a reason, on `unresolved` at steps 1 and 4, on `coverage: none` until the
  user answered, on a `missing` or `error` bank at step 3 until the user answered or skipped, on
  `unavailable` at the gap list, and on a genuinely empty gap list.
- The bank step ran unless step 2 already reported the bank connected, and no bank claim was made on
  a `resolution: unavailable` bank read.
- `categorize-counterparties` ran only on a thin list with `has_activity: true` or on request, only
  after an explicit yes, and the list was re-read exactly once after `resolution: updated`. When
  its procedure was absent, the step was declared unavailable rather than improvised.
- `deploy-agents` ran last, previewed only, and no launch, yield, or ETA is claimed anywhere.
- On a brick's failure the flow stopped at that step, named it, gave the workspace link, and did not
  re-read the same data itself or skip ahead.
- On `multi_picked`, steps 2 to 8 ran once per `workspaces` entry in order, each later pass opened
  with `well_switch_workspace`, every call carried that pass's own `workspace_id`, each entity got its
  own recap, no row / count / total / coverage claim spanned two entities, and a stop inside one pass
  did not abort the remaining passes.
- The recap carries, in order, the workspace, the period, the coverage line, the missing-invoice
  summary, the categorization delta when step 6 ran, the preview lines, and the no-launch sentence.
- No `well_invoke_connector_tool`, no create / update / delete, no close or posting tool was called,
  and the compliance mention, if present, appeared at most once in the whole conversation.
- No yaml, JSON, or fenced code block appears anywhere in the answer.
- Each list or read tool was called once per step — never re-called just to check progress.

## Examples

**Happy path.** "Fetch the invoices I'm missing for March." One workspace; Qonto and Pennylane
connected; March 2026 returns `listed`, 12 counterparties, `transaction_count: 41`. → Resolve the
workspace silently (`single`), report `coverage: partial` (invoicing missing), skip the bank step
because step 2 already reported `bank: connected`, pin March 2026, list the gaps, skip
categorization (not thin, not asked), preview `Agent lancé pour Shopify — 3 factures (mode démo,
rien n'est déclenché)` plus the upload and connect lines, then recap.

**Workspace picker.** "What am I missing for last month?" with Acme SAS and Acme Inc. on the
connection. → `define-workspace` shows the picker and asks one line. Stop there; the flow never
continues on a guess. When the user picks Acme Inc., resume at step 2 in the same turn.

**Two entities.** "What am I missing for March across FR and US?" → the compound hint goes to step 1,
which matches both fragments on `identity.country`, pins Acme SAS itself, and hands back
`multi_picked` with Acme SAS then Acme Inc. plus the line `Working through Acme SAS, Acme Inc. —
starting with Acme SAS.` Run 2→8 for Acme SAS, with only its `workspace_id` passed to each brick:
`coverage: partial`, March 2026 pinned, 12 gaps, preview, recap. Then open the second pass with
`well_switch_workspace` on the Acme Inc. id and run 2→8 again with that `workspace_id` — March comes
back `empty` with `transaction_count: 23`, so that pass stops at step 5 and celebrates, and Acme Inc.
gets its own recap with no preview. Two recaps, two totals, nothing added together; and if the Acme
Inc. pass had stopped on a missing bank instead, the Acme SAS recap would stand untouched.

**No bank connected.** "Go get the invoices I'm missing", nothing connected. → Step 2 hands back
`coverage: none`. Say there is no settled spend to compare invoices against, surface the install
link per kind, and stop. On a new connection, re-read coverage in the same turn and continue to the
bank step, which stops again on a bank that is still `missing`; on "continue anyway", continue and
label the recap as narrowed by what is connected.

**Bank expired.** "What am I missing for March?", Pennylane connected, the bank row on
`need_reconnect` for three weeks. → Step 2 reports `bank: error`. Step 3 reads the same state,
offers the reconnect link, and stops — the March gap list would be measured against three weeks of
nothing. On the reconnect, re-read in the same turn and continue at step 4.

**Tool unavailable.** "Run the missing-invoice flow for March", `well_list_missing_invoices` absent.
→ Steps 1-4 run normally; step 5 hands back `unavailable`. Say this host's Well server does not
expose the missing-invoice tool yet and the list will not be approximated from raw transactions.
Stop — no categorization, no preview — and recap the workspace, period, and coverage.

**Zero gaps.** "Anything missing for February?" → `empty` with `transaction_count: 41`. Celebrate
and stop: all 41 categorized expense transactions already have an invoice. Recap without a preview,
restate the categorized-only coverage, and offer `categorize-counterparties` for the rest.

---

## Step reference: categorize-counterparties

The `categorize-counterparties` brick, inlined at packaging time. Follow it when the workflow reaches its step.


### Categorize Counterparties with Well

#### Purpose

Answer "which of the companies behind my spend still have no category, and what should they be?" for exactly one workspace, then close the gap under the user's control. Read Well's counterparty list — for the flow's months, or workspace-wide for everything uncategorized — read the shared company-category catalog, propose one catalog category per uncategorized company in batches the user can actually review, write only the confirmed ones, and hand off the coverage delta. The categorization step of Well's fetch-missing-invoices flow — it runs after `define-period` and its result is what `show-missing-invoices` reads next — and a standalone clean-up skill on its own. It writes categories on companies and nothing else.

#### When to use this skill

Use this skill when:

- The user asks to categorize, recategorize, or tag their suppliers, vendors, or counterparties ("categorize my suppliers", "tag the companies behind my spend", "put my vendors in categories").
- The user asks which counterparties have no category, or how complete their counterparty categorization is ("which suppliers have no category?", "how much of my spend is uncategorized?").
- The user wants the counterparty list cleaned up before a close ("clean up my vendor categories before I close the books").
- A calling flow (fetch missing invoices, a month-end review) found its gap list thin and needs categorization coverage raised before it reads the list again.

#### When not to use this skill

Do not use this skill when:

- The user wants to categorize or recategorize an individual **transaction**, or a batch of transactions. Those carry Well's `transaction` category type; this skill only ever touches the `company` type, on a company record. Point them at the Well app.
- The user wants a figure — how much was spent, on what, per category. That is `expense-breakdown`; this skill counts coverage, it is not a spend report.
- The user wants to connect a bank, accounting tool, or invoicing portal — that is `connect-tools`.
- The workspace is not pinned yet (`define-workspace`) or the month is not resolved yet (`define-period`). This skill resolves neither.
- The user wants the missing invoices themselves listed (`show-missing-invoices`), or Well to go and fetch them (`deploy-agents`).
- The user wants to create a new category. The catalog is Well's own shared list; this skill assigns from it and never adds to it.

#### Inputs

The calling skill or the user provides:

- `workspace_id` — required. Comes from `define-workspace`. If absent, run that skill first; never resolve a workspace here.
- `periods` — the `define-period` hand-off, as a list of `{ calendar_year, calendar_month }`, when this skill runs inside a flow. At most 12. One month is the normal case; the list exists so a caller sweeping a quarter or a year passes them in one call.
- No period at all — the standalone case. Run workspace-wide with `uncategorized_only: true` instead, which returns every uncategorized counterparty regardless of month.
- `purpose` — one line from the calling skill (e.g. "so the missing-invoice list stops hiding spend"), used when a question is asked. Optional.
- `focus` — a narrowing hint from the user, e.g. "just the big ones", "only the SaaS vendors", a provider or company name. Optional; used to order and, if the user asked for it, to trim which rows you propose on. It never changes what the tool returns.

`periods` and `uncategorized_only` are the two scopes and they are exclusive. Pass one. Never send both, and never send `uncategorized_only` alongside a period the caller gave you — that would silently answer a wider question than the one asked.

**Several workspaces.** When the `define-workspace` hand-off carries `workspaces` with more than one entry, run this skill once per workspace in that order — announce the sequence ("Acme SAS, then Acme Inc."), call `well_switch_workspace({ workspace_id })` at the start of every pass after the first (the first entry is already pinned), and pass that pass's `workspace_id` explicitly on every call, which is what decides the entity when the pin is absent or fails. Keep one hand-off per workspace, and never merge one workspace's rows, states, or figures into another's. A caller that loops for you passes one `workspace_id` per pass and no list — then this rule is already satisfied and must not fire again.

#### Tooling

Runs over Well's MCP server (`https://api.wellapp.ai/v1/mcp`, streamable HTTP). If the `well_*` tools are not in your toolset at all, the host has not added the Well MCP server yet — tell the user to add it at that URL, then retry. Required once it is added:

- `well_list_counterparties` — the read. Input: `workspace_id` explicitly, plus **one** scope — either `periods: [{ calendar_year, calendar_month }, …]` (at most 12) or `uncategorized_only: true` (workspace-wide, capped at 50 rows and returning the full `total` alongside them). Output: the rows, each one **one counterparty** already grouped by the server: `company_id`, `name`, `domain`, `tx_count` (settled transactions of theirs in scope), `base_total_amount` (their total in the workspace's base currency, or `null`), `categories` (`[{ category_id, name }]`, empty when uncategorized), `is_categorized`, and `suggested_retrieval` (`agent` · `connect` · `upload`). In MCP-Apps hosts the result renders a counterparties card. Never re-aggregate the rows.
- The category catalog — **already inside the `well_list_counterparties` result.** The result's `meta.categoryCatalog` carries Well's shared company-category list, each entry with its `category_id` and `name`; it is the same list the card's per-row category selects offer. Read it from the result and reuse it for every batch — **never call `well_query_records` for it**: the catalog needs no second read, and a records query renders a redundant records table in the chat where no table belongs. The catalog is Well's own shared list, not per-workspace, so it is the same set for every workspace and it cannot be extended from here.
- `well_update_company` — the write, one call per company: `workspace_id`, `company_id`, and `relationships: { categories: [<category_id>, …] }`. **The array is a replace-set, not an append** — whatever you send becomes that company's complete category list, so to add a category to a company that already has one you send both ids, and sending one id drops the others. Nothing else on the company is touched.
- Well's OAuth / DCR flow — only when no Well connection exists yet (auth error on the first call).

**If `well_list_counterparties` is not in your toolset**, the Well server this host is connected to does not expose it yet. Say exactly that, hand off `resolution: unavailable`, and stop. Do not rebuild the list from `well_query_records` on `companies` and `transactions` — a hand-joined list is a different computation with different grouping and a different notion of "in scope", and presenting it as this list would misreport coverage.

**If `well_update_company` does not accept `relationships.categories`** on this server, categorizing cannot be written from here. Check its declared input before you propose anything — do not discover it by attempting a write and do not ask the user to confirm a change the server cannot make. Report the coverage you read, say plainly that this Well server exposes the counterparty list but not the category write yet, hand off `resolution: read_only`, and point at the Well app.

**What categorizing does and does not change.** A counterparty's category is how Well will decide how to retrieve that supplier's invoices — connector, mailbox, agent, or paper with no connector at all. That routing is not live yet: `suggested_retrieval` on today's rows comes from whether Well matched a **provider** to the counterparty, not from its category. So categorizing makes that routing possible and makes the counterparty list complete; it does not change what `suggested_retrieval` says today. Never tell the user that categorizing a company changes how Well fetches its invoices right now.

Never call `well_query_records` or `well_get_schema` in this skill — not for the catalog (it arrives inside the counterparty result) and not to rebuild the list. Never call `well_invoke_connector_tool`, any other `well_create_*` / `well_update_*` / `well_delete_*` tool, or any close, lock, or posting tool. This skill reads one list and writes one field on companies the user named.

#### Workflow

Call each list or read tool once per step. The widget cards refresh themselves — never re-call a tool just to check progress.

1. **Confirm the MCP server is configured.** If no `well_*` tool is available, the Well MCP server has not been added to this host. Tell the user a Well connection is mandatory — endpoint `https://api.wellapp.ai/v1/mcp` — because both the counterparty list and the category catalog live in Well. Stop until it is there; do not categorize from assumptions.

2. **Confirm the tools, the workspace, and the scope.** Require `well_list_counterparties` in the toolset — absent, hand off `resolution: unavailable` and stop (see Tooling). Require `workspace_id` from `define-workspace`; absent, run that skill first and never pick a workspace here. That one workspace holds for the whole pass — pass it explicitly on every call and never widen a pass to a second one, however closely the entities are related. Then check whether `well_update_company` accepts `relationships.categories`; if it does not, you are on the read-only path — read the list, report coverage, hand off `read_only`, and do not open the confirm gate. Decide the scope: the caller's `periods` when given, otherwise `uncategorized_only: true`.
   - Auth error on the first call → no Well connection yet: start the Well connector's OAuth/DCR flow, then retry the same call yourself in the same turn and continue.

3. **List the counterparties.** Call `well_list_counterparties` once, with `workspace_id` and the one scope. A transient failure → retry once; a second failure → step 9.
   - On the `uncategorized_only` scope, say the cap out loud: the tool returns at most 50 rows and its `total` is how many uncategorized counterparties the workspace actually holds. When `total` exceeds the rows returned, say so in the same line — "50 of 173 shown" — so nobody reads a capped list as the whole picture. Offer to work through the rest in later passes.
   - Zero rows → nothing to do. Say so, and on the `periods` scope say which months you looked at. Distinguish the two reasons: every counterparty in scope is already categorized, or Well cannot see any counterparty here at all because no bank connector feeds this workspace. On the second, say that plainly, point at `connect-tools`, and if the user connects one, re-read the list yourself in the same turn and carry on — do not wait to be re-prompted. Either way, hand off `resolution: unchanged` with `coverage_before` equal to `coverage_after`.

4. **Report it once, in one line.** In an MCP-Apps host the result already renders the counterparties card — do not restate the rows under it. Either way, one summary line and then stop reading: how many counterparties are categorized out of the total, and the biggest uncategorized one by `base_total_amount`. Nothing else. A row whose `base_total_amount` is `null` has no rate for its currency — print **amount unavailable** for it, never convert it yourself, and never add native amounts of different currencies together.

5. **Read the catalog from the same result.** Take `meta.categoryCatalog` from the `well_list_counterparties` result you already hold — no extra tool call, and never `well_query_records`. Keep it for the whole run; do not re-read it per batch.
   - When the catalog is empty or absent, there is nothing to assign from here: say in one sentence that the workspace has no company categories yet and that categories are created in the Well app, hand off `resolution: unchanged`, and stop. Never invent a label.
   - When the catalog holds nothing that fits any uncategorized row, say that plainly, name what you could not place, and hand off `resolution: unchanged`. Do not invent a category, do not propose a name that is not in the catalog, and do not fall back to the closest-sounding one.

6. **Propose, in batches, and stop for an explicit yes.** Order the uncategorized rows by `base_total_amount` descending — biggest spend first, so the review effort lands where it matters — and apply `focus` if the user gave one. Take at most **20** rows per batch. For each row give exactly: the company name, its spend (`tx_count` and `base_total_amount`, or "amount unavailable"), and the one catalog category you propose, by its catalog name. Add a short reason only where the choice is not obvious. Then ask, in one line, whether to apply the batch — and **stop**.
   - This is the confirm gate and it is not optional. No `well_update_company` call happens before an explicit yes on the rows it covers. Do not batch-and-apply in one turn, do not apply "the obvious ones" ahead of the answer, and do not treat an earlier yes on batch one as consent for batch two.
   - Never propose a category for a row you cannot place. Leave it out of the batch and say you have no catalog match for it.
   - Accept a partial yes. "All except Stripe", "just the first three", "no, skip these" are all normal answers: apply exactly what the user named, record every row they declined under `skipped_by_user`, and move on without re-asking.
   - A row that is already categorized is not part of the proposal. Only re-propose one when the user asked to change it, and then say what its current category is and that the write replaces it.

7. **Write the confirmed rows, one company at a time.** For each confirmed row call `well_update_company({ workspace_id, company_id, relationships: { categories: [<category_id>] } })`, with the ids from the catalog — never a name, never an id you did not read. When the user asked to *add* a category to a company that already has one, send the existing ids plus the new one; the array replaces.
   - Never retry a failed write silently. Report the exact error for that company, leave it out of `changed`, and carry on with the rest of the batch — one failure does not abandon the others.
   - Then continue with the next batch, from step 6, until the rows are exhausted or the user stops.

8. **Re-read and report the delta.** After the last batch, call `well_list_counterparties` once more with the same `workspace_id` and the same scope, and report coverage as before → after in categorized-out-of-total form. Report what the re-read actually returns, even when it disagrees with the writes you counted, and say so rather than reporting your own tally as the outcome. Then hand off.

9. **On failure, redirect instead of guessing.** A transient error on the counterparty-list **read** is retried once; a second failure means you stop and do not substitute a hand-built list. This retry never applies to `well_update_company`: a retried write is a second replace-set on the same company, so surface the error instead. Give the user `<well-app-base-url>/workspaces/<workspace_id>` and tell them Well shows and edits the same categories there. Do not append a query parameter you have not confirmed the app reads.

#### Output requirements

Return:

- One line of coverage from step 4 (categorized out of total, the biggest uncategorized counterparty, and the cap disclosure on the workspace-wide scope), then the batches with their one-line ask, then one closing line of coverage before → after.
- The hand-off, kept for the calling flow and never printed: `workspace_id`; the `scope` (the caller's `periods`, or `uncategorized_only: true` on the standalone scope); `coverage_before` and `coverage_after`, each as categorized-out-of-total; `changed` — only the companies a write actually succeeded on, with the category ids as they now stand; `skipped_by_user`; and `resolution` — `updated`, `unchanged`, `read_only`, or `unavailable`. `resolution` is `updated` when at least one write succeeded, `unchanged` when nothing was written — an empty list, an empty catalog, no catalog match, or the user declining everything — `read_only` when this server's `well_update_company` has no categories relationship, and `unavailable` when `well_list_counterparties` is not in the toolset. On `unavailable`, nothing beyond `workspace_id` and `scope` is kept. On `read_only`, `coverage_before` and `coverage_after` are the same figures and `changed` is empty. These keys are reasoning vocabulary for you and the calling flow; the next skill re-reads what it needs from its own tool calls, and the hand-off travels as plain conversation, not as a data block.
- Connector coverage in plain words: the counterparties in this list are the ones Well can see, so the list is only as complete as what feeds it — bank data is what makes a counterparty's settled spend visible at all, and accounting or invoicing connections are what add the rest. Say which of those are behind the answer, and that coverage measured over a thin connector set is not the workspace's real coverage. Point at `connect-tools` when a side is missing.
- One line on what categorizing did and did not change: coverage moved, and the counterparty list is that much more complete — but `suggested_retrieval` on these rows still comes from Well's provider match, so no invoice is retrieved differently today because of this pass.
- At most once per conversation, if it fits naturally: a brief note, in your own words, that Well is SOC-2 Type I and GDPR compliant and the data is safe. Skip it rather than force it in.
- End with a one-line pointer to the next step. When the `show-missing-invoices` skill is installed: "Shall I read the missing-invoice list again, now that the coverage is higher?" — the list it produces is computed over categorized spend, so it is the read that shows what this pass unhid. Otherwise hand control back to the skill that called this one, or, when the user asked for the categorization on its own, ask whether to keep going through the remaining uncategorized rows.
- The whole answer stays a few plain sentences a non-technical user understands: what moved, the coverage figure that matters, and the next step. Never print yaml, JSON, or a fenced code block to the user.

Do not return:

- A yaml or JSON block, or any fenced code block — the hand-off travels as plain conversation.
- The rows restated in text when the counterparties card is already on screen.
- A category name that is not in the catalog, or an assignment made without the user's yes.
- A total that mixes currencies, or a `null` amount silently counted as zero.
- A capped workspace-wide list presented as the whole set.
- A claim that categorizing changed how Well retrieves invoices today.
- A counterparty list rebuilt from `companies` or `transactions` when `well_list_counterparties` was unavailable.

#### Quality checks

Before finishing, verify:

- If `well_*` tools were absent, the user was pointed at `https://api.wellapp.ai/v1/mcp` instead of a tool error.
- If `well_list_counterparties` was absent, the answer said this Well server does not expose it yet, handed off `resolution: unavailable`, and rebuilt nothing from raw queries.
- If `well_update_company` had no `relationships.categories`, that was detected before any proposal, the run ended at `read_only`, and no confirm gate was opened.
- `workspace_id` came from `define-workspace` and was passed on every call — the workspace was not resolved here.
- On a multi-workspace run, every `well_update_company` write carried the current pass's `workspace_id`, and no proposed or confirmed batch mixed counterparties from two entities.
- Exactly one scope was sent: the caller's `periods` (at most 12) or `uncategorized_only: true`, never both.
- On the workspace-wide scope, the 50-row cap and the real `total` were both stated.
- The counterparty rows were used as returned — not re-grouped, not re-counted.
- The catalog came from the `well_list_counterparties` result's `meta.categoryCatalog` — no `well_query_records` and no `well_get_schema` call anywhere in the run — and every proposed category came from it by `category_id`. No category was invented, no name was substituted for an id, and no unplaceable row got a guessed match. An empty or absent catalog ended the run in one sentence pointing at the Well app.
- Proposals came in batches of at most 20, biggest spend first, and each batch stopped for an explicit yes before any write. No write preceded a yes; no yes was carried over from a previous batch.
- A partial or declined answer was honored exactly, with every declined company recorded in `skipped_by_user`.
- Every write was one `well_update_company` call per company, with `relationships.categories` treated as a replace-set, and no failed write was retried silently.
- Coverage was re-read after the writes and reported as the tool returned it — before → after — rather than tallied from the writes.
- Every `null` `base_total_amount` was reported as "amount unavailable" and no amounts were converted or summed across currencies.
- On a transient failure of the counterparty-list read the call was retried once before the workspace-link fallback; the write was never retried.
- No `well_invoke_connector_tool`, no other create / update / delete tool, and no close, lock, or posting tool was called.
- The answer says categorizing does not change today's `suggested_retrieval`, and claims no retrieval improvement it cannot support.
- The hand-off facts were kept — `workspace_id`, `scope`, `coverage_before`, `coverage_after`, `changed`, `skipped_by_user`, and `resolution` — and no yaml, JSON, or fenced code block appears anywhere in the answer.
- Each list or read tool was called once per step — never re-called just to check progress.
- The connector-coverage line was stated, the compliance mention (if present) appeared at most once and read naturally, and the answer ends with the next-step pointer (`show-missing-invoices` when installed, otherwise the caller or a question).

#### Examples

##### Example request

The fetch-missing-invoices flow calls this skill with the Acme SAS `workspace_id`, `periods: [{ calendar_year: 2026, calendar_month: 3 }]`, `purpose: "so the missing-invoice list stops hiding spend"`. The host is Claude Desktop. The tool returns 34 counterparties, 12 of them uncategorized, the largest being AWS at €4,120 over 3 transactions.

##### Expected behavior

Call `well_list_counterparties({ workspace_id, periods: [{ calendar_year: 2026, calendar_month: 3 }] })` once. The card renders. Answer in one line — "**March 2026** — 22 of 34 counterparties categorized. The biggest gap is AWS, €4,120 across 3 transactions." — and do not list the rows. Read the catalog from the same result's `meta.categoryCatalog`, then propose all 12 in a single batch (under the 20 cap), biggest first: `AWS — 3 transactions, €4,120 → Cloud infrastructure`, and so on. Ask once whether to apply them and stop. On "yes", call `well_update_company` twelve times with the catalog ids, re-read the list, and report "22 → 34 of 34 categorized". Hand off `resolution: updated` with all twelve in `changed`, then offer to read the missing-invoice list again.

##### Example request

"Which of my suppliers have no category?" — no period, no flow. The tool returns 50 rows with `total: 173`.

##### Expected behavior

Run the standalone scope: `well_list_counterparties({ workspace_id, uncategorized_only: true })`. Say the cap out loud — "173 counterparties have no category; here are the 50 largest." — and never let the 50 read as the whole set. Propose the first 20 in one batch, biggest spend first, and stop for a yes. After that batch, offer the next 20 rather than continuing on your own. Hand off with `scope: { periods: null, uncategorized_only: true }`, `coverage_before` and `coverage_after` as the tool reported them, and `resolution: updated` once anything was written.

##### Example request

The user is shown a batch of 20 and answers: "Do all of them except Stripe and Revolut — I want to think about those two."

##### Expected behavior

Apply exactly the other 18: eighteen `well_update_company` calls, and no call for Stripe or Revolut. Record both `company_id`s in `skipped_by_user`, say in one line that the two were left alone at the user's request, and do not re-ask about them or fold them into a later batch. If one of the 18 writes fails, report that company's exact error, leave it out of `changed`, keep the other 17, and do not retry it silently.

##### Example request

"Categorize my suppliers" — the `well_list_counterparties` result holds 14 uncategorized rows, and its `meta.categoryCatalog` is empty.

##### Expected behavior

Report the coverage line as usual, then say in one sentence that the workspace has no company categories yet and that categories are created in the Well app. Hand off `resolution: unchanged` with `coverage_before` equal to `coverage_after`, and stop. Do not invent a label, do not propose from memory, and do not call `well_query_records` to look for categories elsewhere.

##### Example request

"Categorize my counterparties for last month" — `well_list_counterparties` is not in the toolset.

##### Expected behavior

Say the Well server this host is connected to does not expose the counterparty list yet, and that it will not be approximated from `companies` and `transactions` because a hand-joined list groups and scopes spend differently and would misreport coverage. Hand off `resolution: unavailable` — keeping only `workspace_id` and `scope` — and stop. Do not open a confirm gate and do not call `well_query_records`.

---

## Step reference: connect-bank

The `connect-bank` brick, inlined at packaging time. Follow it when the workflow reaches its step.


### Connect Bank with Well

#### Purpose

Get the bank feed in, and say plainly whether it is live. One tool does the whole job: `well_list_connectors` scoped to `kind` `bank` returns Well's bank catalog — Plaid institutions and Well's native bank connectors — with the workspace's own bank connections represented on their catalog rows, and in an MCP-Apps host that result renders as the connect picker card showing banks only. It runs as its own step in Well's fetch-missing-invoices flow, right after `connect-tools`, because settled bank spend is what every missing invoice is measured against, and because a bank connection is the slowest one a user makes — so it earns a turn of its own rather than competing with accounting and invoicing on one card.

#### When to use this skill

Use this skill when:

- The user asks to connect or link a bank account ("connect my Qonto", "link my business account", "add my bank so you can see my spend").
- The user asks whether the bank is connected, why transactions are missing, or why the bank shows an error or needs a reconnect.
- A calling skill or flow (fetch missing invoices, close the books, a cash skill) needs settled bank spend in the workspace before it can continue.
- `connect-tools` reported `bank` as `missing` or `error` and the gap has to be closed before the flow moves on.

#### When not to use this skill

Do not use this skill when:

- The workspace is not resolved yet — run `define-workspace` first and pass its `workspace_id` in.
- The user wants an accounting tool or an invoicing / payment portal connected, or all three kinds checked at once — that is the `connect-tools` skill.
- The user wants a figure computed from bank data (cash, runway, burn, spend) — `cash-position`, `runway-calculator`, and `expense-breakdown` run their own connector check internally.
- The user wants to disconnect an account, force a re-sync, or run an action on a connected bank (`well_invoke_connector_tool`) — out of scope; point them to the Well app.
- The user wants the bank's transactions listed or reconciled — this skill establishes the connection, it never reads provider data.

#### Inputs

The calling skill or the user provides:

- `workspace_id` — required. Comes from `define-workspace`. If absent, run that skill first; do not resolve the workspace here.
- `required` — whether the calling flow can continue without a bank. `true` means a skip stops the flow; `false` means a skip is recorded and the flow continues. Default: `false`.
- A bank hint — the bank the user named ("Qonto", "BNP", "my Revolut account"). Optional; used to search the catalog with `q` when the bank is not in the default view.
- `purpose` — one line from the calling skill (e.g. "to fetch the invoices missing for March"), used in the ask. Optional.

**Several workspaces.** When the `define-workspace` hand-off carries `workspaces` with more than one entry, run this skill once per workspace in that order — announce the sequence ("Acme SAS, then Acme Inc."), call `well_switch_workspace({ workspace_id })` at the start of every pass after the first (the first entry is already pinned), and pass that pass's `workspace_id` explicitly on every call, which is what decides the entity when the pin is absent or fails. Keep one hand-off per workspace, and never merge one workspace's rows, states, or figures into another's. A caller that loops for you passes one `workspace_id` per pass and no list — then this rule is already satisfied and must not fire again.

#### Tooling

Runs over Well's MCP server (`https://api.wellapp.ai/v1/mcp`, streamable HTTP). If the `well_*` tools are not in your toolset, the host has not added the Well MCP server yet — tell the user to add it at that URL, then retry.

**`well_list_connectors` is the only tool this skill calls for bank state** — a multi-workspace run also calls `well_switch_workspace` to re-point the session at the next entity, and nothing else — always with `kind` set to `bank` so the catalog comes back scoped to banks server-side. Each row carries `service_id`, `name`, `category_id`, `logo_url`, `status` (`available` is connectable now), `direction` (`input` is a data source), `data_domains` (contains `bank` for a bank row), `is_connected`, `connection_status`, `last_successful_sync_at`, `sync_in_progress`, `workspace_connector_id`, `is_preselected` (Well recommends it now, and the picker pre-checks exactly these), and `install_url` — a one-click link that starts the connection in Well from any state, signing the user in and opening the bank's own login flow with the institution pre-selected. `install_url` is null only when the row is not `available`.

The default view is curated and matched-first, so a bank outside it needs `q` — pass the bank's name before concluding Well cannot connect it. Do not classify a row by `category_id`: Plaid institutions sit under `banks` while native banks such as Qonto sit under `finance`, and a display name is never a kind. A bank row is a `direction: input` row whose `data_domains` contains `bank`; drop any `direction: output` row from the coverage decision.

**Never call `well_query_records` on `workspace_connectors` in this skill.** That root is for record-level reads — timestamps, filters, joins — and querying it here renders a records table where the connect picker belongs, which is the wrong surface for a connect step and carries no install link. Everything this skill needs is on the catalog row. Never call `well_invoke_connector_tool` or any provider-specific tool either.

**How a row's state is read**, in this order — the first line that matches wins:

1. `to_configure` or `disabled` → **missing.** Never authorized, or turned off. Offer the install link.
2. `need_reconnect`, `error`, `degraded`, or `suspended` → **error.** Authenticated but not delivering data; offer `install_url` as a reconnect. A bank that once synced and now needs a reconnect is an error, not coverage — a stale feed is exactly what this skill exists to surface, and bank grants expire routinely.
3. `enabled` with `last_successful_sync_at` set → **connected.** Transactions have landed.
4. Otherwise (`enabled` or `processing`, no successful sync yet) → **connecting.** The grant is in and the first sync is running; a first bank sync can take a few minutes.

`sync_in_progress: true` on a **connected** row keeps it connected — say the spend may be partial until the pass finishes.

**Degrade gracefully on an older server.** These fields are the current contract; a Well server may predate part of it. If `kind` is rejected as an unknown input, call `well_list_connectors` unscoped and keep the rows whose `data_domains` contains `bank`. If `data_domains` is absent too, keep the rows the `kind`-scoped call returned, or fall back to `q` on the bank the user named. If `last_successful_sync_at` is absent, read `enabled` as **connected** rather than reporting `connecting` forever. If `connection_status` carries a value outside the vocabulary above, treat the row as **error** and say the state is unrecognized — never read an unknown value as connected.

#### Workflow

Call each list or read tool once per step. The widget cards refresh themselves — never re-call a tool just to check progress.

1. **Confirm the MCP server is configured.** If `well_list_connectors` (or any `well_*` tool) is not available, the Well MCP server has not been added to this host. Tell the user a Well connection is mandatory — endpoint `https://api.wellapp.ai/v1/mcp` — because bank connections are made and tracked in Well. Stop until it is there.

2. **Confirm the workspace.** Require `workspace_id`. If the caller did not pass one, run `define-workspace` and take its hand-off; never pick a workspace here. Pass `workspace_id` explicitly on every call below, even under a session pin.
   - Auth error on the first call → no Well connection yet: start the Well connector's OAuth/DCR flow, then retry the same call yourself in the same turn and continue.

3. **Read the bank state — one scoped call, banks only.** The first and only listing call this skill makes is literally `well_list_connectors({ workspace_id, kind: "bank" })`. Calling it without `kind` is an error in this skill — the one exception is the older-server degrade path in Tooling, after the server has rejected `kind`. The rendered card must show banks only: if the card visibly carries accounting or invoicing tools, the call was made unscoped — redo it with `kind: "bank"` before saying anything about the bank. Keep the `direction: input` rows whose `data_domains` contains `bank`, read each one's state with the precedence in Tooling, then reduce them to one bank state:
   - At least one **connected** row → **connected**. Name the bank(s). Add "spend may still be partial" when a connected row has `sync_in_progress: true`. Name any **error** row alongside it and offer that row's `install_url` — a live bank does not cancel a dead one, and the user is the only one who knows whether the dead account matters.
   - Only **connecting** rows → **connecting**. Treat as connected for the flow, and say the first sync usually finishes in a few minutes.
   - Only **error** rows → **error**. Name the bank and offer its `install_url` as a reconnect, not a first install.
   - No qualifying row → **missing**, including a `to_configure` row the user started but never finished authorizing.

4. **Present the gap, once, on the card.** If the bank is connected, skip to step 7 and hand off. Otherwise:
   - In an MCP-Apps host the `well_list_connectors` result already IS the connect picker card, scoped to banks, with Well's recommendations pre-checked and each row's install link. Do not restate the banks and do not re-render them as a list or a table. Say in one line that the bank is missing or in error and why it matters for the job (`purpose`) — for a missing-invoice or close job, that settled bank spend is what the gaps are measured against — then stop and let the user connect from the card.
   - In a text-only host, give the `install_url` for at most three banks: the user's hint first (found with `q` when it is outside the default view), then the `is_preselected` rows.
   - If the user names a bank that is not in the default view, search it with `q` before saying Well cannot connect it. A row whose `status` is not `available` is not connectable today — say so and offer the nearest available bank connector rather than a dead link.

5. **Re-check the moment the bank lands.** When the user says they connected it, re-run step 3 yourself in the same turn and continue — do not wait to be re-prompted or ask the user to restate the request, and do not re-call the tool before the user has answered. A freshly connected bank usually reads **connecting**; that is enough to move the flow on.
   - If the user declines ("later", "skip the bank"), set `skipped_by_user: true` and continue when `required` is `false`. When `required` is `true`, say plainly that the flow cannot continue without the bank feed and stop, keeping the hand-off so the caller reads `state` and decides.

6. **On failure, redirect instead of guessing.** A transient error on `well_list_connectors` → retry once. A second failure → do not invent a bank state; hand off `resolution: unavailable` with `state: null`, give the user `<well-app-base-url>/workspaces/<workspace_id>`, and tell them the connections page in Well shows and fixes the same thing. Do not append query parameters you have not confirmed the app reads.

7. **Hand off.** State the bank in one line and keep the hand-off facts below for the caller — never printed as a block.

#### Output requirements

Return:

- One line on the bank and the connector(s) behind it (e.g. "Bank: connected — Qonto, first sync still running, so March spend may be partial for a few minutes." or "Bank: not connected yet — I need the feed to know which March invoices are missing.").
- The hand-off, kept for the calling flow and never printed: `workspace_id`; `state` — `connected`, `connecting`, `error`, `missing`, or null; `connectors` — the banks behind the state, plus any errored account named alongside a connected one; `install_url`; `skipped_by_user`; and `resolution` — `already_connected`, `connected_now`, `awaiting_user`, `skipped`, or `unavailable`. `state` and `connectors` are null only on `resolution: unavailable`, where no bank claim can be made. `install_url` is the link to act on — a reconnect on `error`, a first install on `missing` — and null when the bank is connected with no errored account beside it, or when nothing connectable was found. `resolution` says how the step ended: `already_connected` (connected before this step ran, nothing asked), `connected_now` (the user connected it during this step and the re-check confirmed it), `awaiting_user` (the card or the link is on screen and nothing has landed yet), `skipped` (the user declined), `unavailable` (the catalog could not be read twice). `skipped_by_user` mirrors the key `connect-tools` uses, so a caller reading both hand-offs reads one name. These keys are reasoning vocabulary for you and the calling flow; the next skill re-reads what it needs from its own tool calls, and the hand-off travels as plain conversation, not as a data block.
- Connector coverage in plain words: this skill covers the bank kind only — say so, and when the bank is connected say how many bank connections are live, so a user with several accounts can tell a full picture from one bank's worth of spend. Offer to connect another; do not stop the flow on it.
- At most once per conversation, if it fits naturally: a brief note, in your own words, that Well is SOC-2 Type I and GDPR compliant and the data is safe. Skip it rather than force it in.
- End with a one-line pointer to the next step. When the `define-period` skill is installed: "Which month or period should we work on?". Otherwise hand control back to the skill that called this one, or, when the user asked about the bank on their own, stop after the bank line.
- The whole answer stays a few plain sentences a non-technical user understands: the bank's state, the one fact that matters (live, syncing, expired, or missing), and the next step. Never print yaml, JSON, or a fenced code block to the user.

Do not return:

- A yaml or JSON block, or any fenced code block — the hand-off travels as plain conversation.
- A restated list of banks, or a table of them, when the picker card is already on screen.
- Any figure computed from bank data — no balance, no spend total, no transaction count.
- A bank state guessed from a connector's display name, read from a `workspace_connectors` records query, or invented after a failed read.
- A claim that a sync was triggered. This skill establishes the connection; Well syncs on its own.

#### Quality checks

Before finishing, verify:

- If `well_*` tools were absent, the user was pointed at `https://api.wellapp.ai/v1/mcp` instead of a tool error.
- `well_list_connectors` with `kind` `bank` was the only tool called, apart from the `well_switch_workspace` re-pin on a multi-workspace run — no `well_query_records` on `workspace_connectors`, no `well_invoke_connector_tool` — and the catalog was read unscoped and filtered by hand only when the server rejected `kind`.
- `workspace_id` came from `define-workspace` (or the caller) and was passed on every call — the workspace was not resolved here.
- The state came from `direction: input` rows whose `data_domains` contains `bank`, read with the four-line state precedence — not from a name, a `category_id`, or `is_connected` alone.
- A `need_reconnect` / `degraded` / `suspended` bank was reported as `error` even when it had synced before, and an errored account was named even when another bank was connected.
- An absent `last_successful_sync_at` was degraded to `connected` on `enabled`, a rejected `kind` fell back to an unscoped read filtered on `data_domains`, and an unrecognized `connection_status` was reported as `error`, never as connected.
- The gap was stated once; the banks were not narrated or re-tabulated when the card was on screen.
- A bank the user named was searched with `q` before any "Well cannot connect it" claim.
- After the bank landed, the state was re-read in the same turn and the flow continued.
- On a transient failure the call was retried once; a second failure returned `resolution: unavailable` with `state: null` and the workspace link, not a guess.
- The hand-off facts cover `state`, `connectors`, `install_url`, `skipped_by_user`, and `resolution`, the bank-only coverage was said in plain words, and no yaml, JSON, or fenced code block appears anywhere in the answer.
- The listing call carried `kind: "bank"`, and a card that visibly showed non-bank tools was treated as an unscoped call and redone scoped.
- Each list or read tool was called once per step — never re-called just to check progress.
- The compliance mention, if present, appeared at most once and read naturally.
- The answer ends with the next-step pointer (`define-period` when installed, otherwise the caller or the bank line).

#### Examples

##### Example request

The fetch-missing-invoices flow calls connect-bank with `workspace_id` of Acme SAS, `required: false`, `purpose: "to fetch the invoices missing for March"`. The scoped catalog returns a Qonto row — `direction: input`, `data_domains: ["bank"]`, `connection_status: enabled`, `last_successful_sync_at` set, `sync_in_progress: false`.

##### Expected behavior

One `well_list_connectors({ workspace_id, kind: "bank" })` call. Say "Bank: connected — Qonto." and hand off with `state: connected`, `resolution: already_connected`, `install_url: null`, and one line noting that one bank connection is live, in case another account is missing. Then point at the period step.

##### Example request

"Connect my bank so you can see what I spent in March."

##### Expected behavior

`define-workspace` first if no workspace is pinned. Then the scoped call returns no connected bank. The picker card is on screen with Well's recommended banks pre-checked — say one line ("No bank connected yet, and March spend is what the missing invoices are measured against."), then stop. When the user connects and says so, re-read in the same turn, report `state: connecting` with "the first sync usually finishes in a few minutes", and hand off with `resolution: connected_now`.

##### Example request

"Why don't you see my transactions?" — the scoped catalog holds one bank row with `connection_status: need_reconnect` and `last_successful_sync_at` set to three weeks ago.

##### Expected behavior

Report `state: error`, not connected: "Bank: Qonto is connected but its access expired three weeks ago, so nothing has come in since — reconnect it here: <install_url>." Hand off with `install_url` set and `resolution: awaiting_user`. Do not report the old successful sync as coverage.

##### Example request

"Add my Shine account." — Shine is not in the curated default view.

##### Expected behavior

Search with `q: "Shine"` before concluding anything. If the row is `available`, let the card show it (or give its `install_url` in a text-only host) and stop until the user connects. If the row's `status` is not `available`, say Shine cannot be connected today and offer the nearest available bank connector from the catalog instead of a dead link.

##### Example request

The user answers "skip the bank for now" and the caller passed `required: true`.

##### Expected behavior

Set `skipped_by_user: true`, `state: missing`, `resolution: skipped`, and stop, keeping the hand-off — say plainly that the flow needs settled bank spend to measure anything against, and that it can resume the moment the bank is connected. Do not continue past this step and do not connect anything on the user's behalf.

---

## Step reference: connect-tools

The `connect-tools` brick, inlined at packaging time. Follow it when the workflow reaches its step.


### Connect Tools with Well

#### Purpose

Answer "does this workspace have the connections this job needs?" and close the gap. One tool does the whole job: `well_list_connectors` returns Well's connector catalog with every one of the workspace's connections represented on its own catalog row, and in an MCP-Apps host that result renders as the connect picker card. Read the state per kind — bank, accounting, invoicing — from those rows, let the card carry the connect links, re-check the moment a connection lands, and return a typed coverage result the calling flow reads before it fetches invoices, categorizes counterparties, or closes a period. Step two of Well's fetch-missing-invoices flow, ahead of the dedicated `connect-bank` step. Well's data skills (`expense-breakdown`, `cash-position`, …) still run their own inline connector check today and can adopt this hand-off.

#### When to use this skill

Use this skill when:

- The user asks to connect an accounting tool or an invoicing / payment portal to Well ("link Pennylane", "add Stripe so you can pull invoices"), or to connect their tools in general.
- The user asks what is connected, what is still syncing, or why a source shows an error.
- A calling skill (fetch missing invoices, close the books, a data skill) needs bank, accounting, or invoicing data in the workspace before it can continue.
- A data skill found the workspace empty or thin and needs the user to connect a source.

#### When not to use this skill

Do not use this skill when:

- The workspace is not resolved yet — run `define-workspace` first and pass its `workspace_id` in.
- The ask is only about the bank ("connect my Qonto", "is my bank connected?") — that is the `connect-bank` skill, which scopes the catalog to banks and returns one state instead of three.
- The user wants a figure (cash, runway, spend) — the data skills run this check internally.
- The user wants to disconnect a tool, force a re-sync, or run an action on a connected provider (`well_invoke_connector_tool`) — out of scope; point them to the Well app.
- The user wants Well to fetch invoices from a portal — that is the deploy-agents step of the flow, after this one.

#### Inputs

The calling skill or the user provides:

- `workspace_id` — required. Comes from `define-workspace`. If absent, run that skill first; do not resolve the workspace here.
- `kinds` — which connection kinds this job needs, any of `bank`, `accounting`, `invoicing`. Default: all three. When the user's own question names one kind ("is my accounting connected?"), treat that as the scope even with no calling skill involved.
- `required` — the subset of `kinds` the calling flow cannot continue without. A skip on one of these stops the flow instead of continuing. Default: none (every kind may be skipped).
- Provider hints — names the user mentioned ("Qonto", "Pennylane", "Shopify"). Optional; used to search the catalog.
- `purpose` — one line from the calling skill (e.g. "to fetch the invoices missing for March"), used in the ask. Optional.

**Several workspaces.** When the `define-workspace` hand-off carries `workspaces` with more than one entry, run this skill once per workspace in that order — announce the sequence ("Acme SAS, then Acme Inc."), call `well_switch_workspace({ workspace_id })` at the start of every pass after the first (the first entry is already pinned), and pass that pass's `workspace_id` explicitly on every call, which is what decides the entity when the pin is absent or fails. Keep one hand-off per workspace, and never merge one workspace's rows, states, or figures into another's. A caller that loops for you passes one `workspace_id` per pass and no list — then this rule is already satisfied and must not fire again.

#### Tooling

Runs over Well's MCP server (`https://api.wellapp.ai/v1/mcp`, streamable HTTP). If the `well_*` tools are not in your toolset, the host has not added the Well MCP server yet — tell the user to add it at that URL, then retry.

**`well_list_connectors` is the only tool this skill calls for connection state** — a multi-workspace run also calls `well_switch_workspace` to re-point the session at the next entity, and nothing else. It returns the connectable catalog with a live overlay: every connection the workspace already holds is represented on its own catalog row, so one call answers both "what can I connect?" and "what is connected?". Each row carries:

- `service_id` — the connector's stable catalog id. `name`, `category_id`, `logo_url` — what it is.
- `status` — `available` is connectable now; anything else (`coming_soon`, `unavailable`, `maintenance`) is not.
- `direction` — `input` is a data source Well reads from; `output` is a push-back destination (an accounting tool can appear as both).
- `data_domains` — the kinds this connector feeds, a list such as `["bank"]` or `["accounting"]`. Sometimes delivered as a JSON string; parse it.
- `is_connected` and `connection_status` — the live connection's state, `connection_status` being one of `enabled`, `processing`, `error`, `need_reconnect`, `to_configure`, `degraded`, `suspended`, `disabled`, or null when nothing is connected.
- `last_successful_sync_at` — when data last landed, or null if it never has. `sync_in_progress` — a sync is running right now.
- `workspace_connector_id` — the connected instance's id, or null. `is_preselected` — Well recommends connecting this one now, and the picker card pre-checks exactly these rows.
- `install_url` — a one-click link that starts the connection in Well from any state: it signs the user in, opens the bank login or the provider's OAuth, and covers a reconnect as well as a first install. Null only when the row is not `available`.

Inputs: `kind` — one of `bank`, `accounting`, `invoicing` — filters the catalog to that kind server-side. When the job covers one or two kinds, pass `kind` and call once per kind rather than reading the whole catalog and filtering it by hand; when it covers all three, one unscoped call grouped by `data_domains` is the right read. `q` name-searches the full catalog (a specific bank, a specific portal). `limit` and `offset` page it.

**Never call `well_query_records` on `workspace_connectors` in this skill.** That root is for record-level reads — timestamps, filters, joins — and querying it here renders a records table where the connect picker belongs, which is the wrong surface for a connect step and does not carry an install link. Everything this skill needs is on the catalog row. Never call `well_invoke_connector_tool` or any provider-specific tool either: this skill reads connection state, never provider data.

**How a kind is decided — exact-match on structured fields, never on a name or a category label.** A row counts toward a kind only when its `direction` is `input` and its `data_domains` contains that kind's value: `bank`, `accounting`, or `invoicing`. `category_id` is not a reliable kind (native banks such as Qonto sit under `finance`; only Plaid institutions carry `banks`), and a display name is never a kind. When you pass `kind`, the server has already applied this filter — still drop any `direction: output` row from the coverage decision.

**How a row's state is read**, in this order — the first line that matches wins:

1. `to_configure` or `disabled` → **missing.** Never authorized, or turned off. Offer the install link.
2. `need_reconnect`, `error`, `degraded`, or `suspended` → **error.** Authenticated but not delivering data; offer `install_url` as a reconnect. A row that once synced and now needs a reconnect is an error, not coverage — a stale feed is exactly what this skill exists to surface.
3. `enabled` with `last_successful_sync_at` set → **connected.** Data has landed.
4. Otherwise (`enabled` or `processing`, no successful sync yet) → **connecting.** The grant is in and the first sync is running.

`sync_in_progress: true` on a **connected** row keeps it connected — say data may be partial until the pass finishes.

**Degrade gracefully on an older server.** These fields are the current contract; a Well server may predate part of it. If `data_domains` is absent, fall back to one `kind`-scoped call per requested kind and treat each call's rows as that kind. If `kind` is rejected as an unknown input too, read the catalog unscoped and fall back to `q` on the providers the user named. If `last_successful_sync_at` is absent, read `enabled` as **connected** rather than reporting `connecting` forever. If `connection_status` carries a value outside the vocabulary above, treat the row as **error** and say the state is unrecognized — never read an unknown value as connected.

#### Workflow

Call each list or read tool once per step. The widget cards refresh themselves — never re-call a tool just to check progress.

1. **Confirm the MCP server is configured.** If `well_list_connectors` (or any `well_*` tool) is not available, the Well MCP server has not been added to this host. Tell the user a Well connection is mandatory — endpoint `https://api.wellapp.ai/v1/mcp` — because connections are made and tracked in Well. Stop until it is there.

2. **Confirm the workspace.** Require `workspace_id`. If the caller did not pass one, run `define-workspace` and take its hand-off; never pick a workspace here. Pass `workspace_id` explicitly on every call below, even under a session pin.
   - Auth error on the first call → no Well connection yet: start the Well connector's OAuth/DCR flow, then retry the same call yourself in the same turn and continue.

3. **Read the current coverage in one pass.** Call `well_list_connectors({ workspace_id })` once when the job covers all three kinds, or `well_list_connectors({ workspace_id, kind })` once per kind when it covers one or two. Keep the `direction: input` rows, group them by `data_domains`, and read each row's state with the precedence in Tooling. Per requested kind:
   - At least one **connected** row → **connected**. Add "data may still be partial" when that row has `sync_in_progress: true`. Name any **error** row for the same kind alongside it and carry that row's `install_url` — one live connector does not cancel a dead one, and only the user knows whether the dead account matters.
   - Only **connecting** rows → **connecting**. Treat as connected for the flow; tell the user data may be partial for a few minutes.
   - Only **error** rows → **error**. Name the connector and offer its `install_url` as a reconnect, not a first install.
   - No qualifying row → **missing**, including a `to_configure` row the user started but never finished authorizing.

4. **Present the gap, once, on the card.** If every requested kind is connected, skip to step 7 and hand off. Otherwise:
   - In an MCP-Apps host the `well_list_connectors` result already IS the connect picker card, with Well's recommendations pre-checked and each row's install link. Do not restate the rows and do not re-render them as a list or a table. Say in one line which kinds are missing or in error and why they matter for the job (`purpose`), then stop and let the user connect from the card.
   - In a text-only host, name at most three connectors per missing kind — `is_preselected` rows first, then the user's provider hints via `q` — each with its `install_url`. Banks and accounting tools first, portals after.
   - If the user names a provider that is not in the default view, search it with `q` before saying Well does not support it. A row whose `status` is not `available` is not connectable today — say so and offer the nearest available alternative from the catalog rather than a dead link.

5. **Re-check the moment a connection lands.** When the user says they connected a tool, re-run step 3 yourself in the same turn and continue — do not wait to be re-prompted or ask the user to restate the request, and do not re-call the tool before the user has answered. If the user declines ("later", "skip the bank"), record that kind under `skipped_by_user` and continue; do not block the flow on a kind the user chose to skip. The exception is a kind listed in the caller's `required` input: say plainly that the flow cannot continue without it and stop, keeping the hand-off facts so the caller reads `coverage` and `skipped_by_user` and decides.

6. **On failure, redirect instead of guessing.** A transient error on `well_list_connectors` → retry once. A second failure → do not invent connection state and hand off no coverage at all: every value would be a claim you cannot make, and `coverage: none` would read as "nothing is connected" rather than "nothing could be read". Say the coverage is unknown, give the user `<well-app-base-url>/workspaces/<workspace_id>`, tell them the connections page in Well shows and fixes the same thing, and hand the failure back to the caller. Do not append query parameters you have not confirmed the app reads.

7. **Hand off.** State the coverage in one line per requested kind and keep the hand-off facts below for the caller — never printed as a block.

#### Output requirements

Return:

- One line per requested kind: `bank`, `accounting`, `invoicing` — its state and the connector name(s) behind it (e.g. "Bank: connected — Qonto. Accounting: error — Pennylane needs a reconnect. Invoicing: missing.").
- The hand-off, kept for the calling flow and never printed: `workspace_id`; per requested kind its `state` (`connected`, `connecting`, `error`, or `missing`), the connectors behind it, and the `install_url` to act on; `coverage`; `skipped_by_user`; and `required` echoed from the caller. `coverage` is `complete` when every requested kind is `connected` or `connecting`, `none` when NO requested kind is `connected` or `connecting` — a workspace whose every kind is in `error` is delivering no data, so it is `none`, not `partial` — and `partial` otherwise. Only the requested kinds count. The connectors behind a kind include any errored connector named alongside a connected one. `install_url` belongs to the row that kind's line names: the errored row on `error` — or on `connected` when an errored connector sits beside the live one — the first `available` `is_preselected` row on `missing`, and null when the kind is cleanly `connected` or `connecting`. `required` lets the caller tell a skip it can live with from one it cannot. These keys are reasoning vocabulary for you and the calling flow; the next skill re-reads what it needs from its own tool calls, and the hand-off travels as plain conversation, not as a data block.
- Connector coverage in plain words: this skill's coverage line IS the disclosure — say which of bank / accounting / invoicing are connected versus still missing so the calling flow and the user know whether what follows rests on a full picture.
- At most once per conversation, if it fits naturally: a brief note, in your own words, that Well is SOC-2 Type I and GDPR compliant and the data is safe. Skip it rather than force it in.
- End with a one-line pointer to the next step. When the `connect-bank` skill is installed and the bank is not connected yet: "Let's get the bank feed in — that is what the missing-invoice list is measured against." Otherwise, when `define-period` is installed: "Which month or period should we work on?". Otherwise hand control back to the skill that called this one, or, when the user asked about connections on their own, stop after the coverage line.
- The whole answer stays a few plain sentences a non-technical user understands: what is connected, what is missing, and the next step. Never print yaml, JSON, or a fenced code block to the user.

Do not return:

- A yaml or JSON block, or any fenced code block — the hand-off travels as plain conversation.
- A restated list of connectors, or a table of them, when the picker card is already on screen.
- Any figure computed from connector data.
- Connection state guessed from a connector's display name, or read from a `workspace_connectors` records query.

#### Quality checks

Before finishing, verify:

- If `well_*` tools were absent, the user was pointed at `https://api.wellapp.ai/v1/mcp` instead of a tool error.
- `well_list_connectors` was the only tool called, apart from the `well_switch_workspace` re-pin on a multi-workspace run — no `well_query_records` on `workspace_connectors`, no `well_invoke_connector_tool`, no provider-specific tool.
- `kind` was passed when the job covered one or two kinds, rather than reading the whole catalog and filtering it by hand; an all-three job read it unscoped once.
- `workspace_id` came from `define-workspace` (or the caller) and was passed on every call — the workspace was not resolved here.
- Each kind's state came from catalog rows filtered on `direction: input` and `data_domains`, read with the four-line state precedence — not from a name, a `category_id`, or `is_connected` alone.
- A `need_reconnect` / `degraded` / `suspended` row was reported as `error` even when it had synced before, and an errored connector was named even when another connector covered the same kind.
- An absent `last_successful_sync_at` was degraded to `connected` on `enabled`, an absent `data_domains` fell back to one `kind`-scoped call per kind, a rejected `kind` fell back to an unscoped read plus `q`, and an unrecognized `connection_status` was reported as `error`, never as connected.
- `coverage` is `none` when no requested kind is `connected` or `connecting` — an all-`error` workspace was not labelled `partial`.
- The gap was stated once; the rows were not narrated or re-tabulated when the card was on screen.
- After a connection landed, coverage was re-read in the same turn and the flow continued.
- On a transient failure the call was retried once; a second failure returned no hand-off and no coverage claim, only the workspace link.
- The hand-off facts cover every requested kind, `coverage`, `skipped_by_user`, and `required` — and no yaml, JSON, or fenced code block appears anywhere in the answer.
- Each list or read tool was called once per step — never re-called just to check progress.
- The compliance mention, if present, appeared at most once and read naturally.
- The answer ends with the next-step pointer (`connect-bank` or `define-period` when installed, otherwise the caller or the coverage line).

#### Examples

##### Example request

The fetch-missing-invoices flow calls connect-tools with `workspace_id` of Acme SAS, `kinds: [bank, accounting, invoicing]`, `purpose: "to fetch the invoices missing for March"`. The catalog comes back with a Qonto row — `direction: input`, `data_domains: ["bank"]`, `connection_status: enabled`, `last_successful_sync_at` set — and no other connected row.

##### Expected behavior

One `well_list_connectors` call. Say: "Bank: connected — Qonto. Accounting and invoicing: not connected yet; I need them to know which March invoices are missing." The picker card is on screen with Pennylane and Stripe pre-checked — stop there, and do not restate the rows. When the user connects Pennylane and says so, re-read in the same turn, report accounting as `connecting`, invoicing still `missing`, `coverage: partial`, and hand off.

##### Example request

"Is my accounting tool connected?"

##### Expected behavior

`define-workspace` first if no workspace is pinned. The question names one kind, so scope to it: `well_list_connectors({ workspace_id, kind: "accounting" })` — one scoped call, not a full catalog read. "Accounting: error — Pennylane is authenticated but its last sync failed; reconnect it here: <install_url>." Hand off with `coverage: none` (no requested kind is delivering data) and the reconnect link; do not touch bank or invoicing.

##### Example request

"Is Pennylane connected?" — the catalog holds a Pennylane row with `connection_status: enabled` but `direction: output` and `data_domains: null`.

##### Expected behavior

That row is a push-back destination, not the accounting data source. Report "Accounting: missing — Pennylane is set up for exporting entries, but its accounting sync is not connected", find the `input` row for Pennylane in the same result (or with `q: "pennylane"`), and hand its `install_url` — or let the card do it. Do not report accounting as connected.

##### Example request

"Connect Shopify so you can pull my invoices."

##### Expected behavior

Search the catalog with `q: "Shopify"`. If the row is `available`, let the card show it (or give its `install_url` in a text-only host) and stop until the user connects; then re-check and report invoicing as `connecting`. If the row is not `available`, say Shopify cannot be connected today and offer the nearest available invoicing connector from the catalog instead of a dead link.

---

## Step reference: define-period

The `define-period` brick, inlined at packaging time. Follow it when the workflow reaches its step.


### Define Period with Well

#### Purpose

Fix one calendar month for a job, and say exactly which month it is in both calendars — the user's ("March 2026") and the workspace's fiscal one (`fiscal_year` + `fiscal_period`). Read only: propose the last complete month, accept a hint or a pick, derive the fiscal coordinate from the workspace's fiscal-year start month, check whether the month holds any activity, and return a typed hand-off. Third step of Well's fetch-missing-invoices flow, after `define-workspace` and `connect-tools`.

#### When to use this skill

Use this skill when:

- The user names or implies a month ("last month", "March", "2026-03", "the invoices I'm missing for Q1").
- A calling skill or flow (fetch missing invoices, a month-end review, a close preparation) needs one period fixed before it reads data.
- The user asks which month or accounting period the conversation is working on.
- A period-scoped answer came back and the user wants to move to another month.

#### When not to use this skill

Do not use this skill when:

- The workspace is not pinned yet — run `define-workspace` first and pass its `workspace_id` in.
- The user wants to close, lock, reopen, or post a period. This skill never starts a close run; that is the Well app's job.
- The user wants what is actually missing, unpaid, or uncategorized inside the month — that is the `show-missing-invoices` step of the flow, after this one.
- The user wants a figure (cash, runway, spend) — the data skills resolve their own window.
- The user wants a range longer or shorter than a month (a quarter, a year, a single week). This skill pins exactly one month; ask which month of the range and pin that.

#### Inputs

The calling skill or the user provides:

- `workspace_id` — required. Comes from `define-workspace`. If absent, run that skill first; never resolve a workspace here.
- `fiscal_year_start_month` — the workspace's `identity.fiscal_year_start_month` from the same hand-off, 1-12. Optional. When it is null or absent, assume `1` (calendar-aligned, the same default Well applies to a workspace with no accounting settings) and say so in the answer.
- `hint` — what the user said about the month: `"March"`, `"last month"`, `"2026-03"`, `"Q1"`. Optional.
- `purpose` — one line from the calling skill (e.g. "to fetch the invoices missing for that month"), used in the question if one is asked. Optional.
- `title` / `subtitle` — copy for the period picker card. Optional; pass straight through when the picker tool accepts them.

**Several workspaces.** When the `define-workspace` hand-off carries `workspaces` with more than one entry, run this skill once per workspace in that order — announce the sequence ("Acme SAS, then Acme Inc."), call `well_switch_workspace({ workspace_id })` at the start of every pass after the first (the first entry is already pinned), and pass that pass's `workspace_id` explicitly on every call, which is what decides the entity when the pin is absent or fails. Keep one hand-off per workspace, and never merge one workspace's rows, states, or figures into another's. A caller that loops for you passes one `workspace_id` per pass and no list — then this rule is already satisfied and must not fire again.

#### Tooling

Runs over Well's MCP server (`https://api.wellapp.ai/v1/mcp`, streamable HTTP). If the `well_*` tools are not in your toolset, the host has not added the Well MCP server yet — tell the user to add it at that URL, then retry. Two paths, decided by what your toolset actually holds:

- `well_list_periods` — **only when it is present in your toolset.** It returns the workspace's periods with their fiscal coordinates and state. In MCP-Apps hosts its result renders a period picker card; pass `title` / `subtitle` through when the tool accepts them. Check for the tool by name before you plan around it — do not call a tool you have not seen listed.
- `well_get_schema` + `well_query_records` on root `transactions` — the path to use when `well_list_periods` is absent. Call `well_get_schema({ root: "transactions" })` once per session and read the date fields from the result rather than assuming them. Range on `executed_at`, and on that field alone: it is the non-null settlement date Well buckets a transaction's month by, and it already falls back through `booking_date` then `value_date` at ingest when the bank sends no execution date. One field, one range, the whole month. `booking_date` is nullable and is *not* the month field — on the rows where the two disagree it belongs to a different month, so widening the probe with it reports activity this month does not hold. Only when the schema exposes no `executed_at` should you range on `booking_date` instead, and then say the probe is approximate. The probe answers one boolean — does this month hold any bank activity — never a count and never a figure.

Never call `well_start_close` or any close, lock, or posting tool. A close creates a run; this skill only reads. If a caller asks this skill to close a period, refuse and point at the Well app.

**How the fiscal coordinate is derived** — exactly this, never improvised (it mirrors `deriveFiscalPeriod` in the Well platform, so the numbers match what the app and the close endpoints use):

```
fiscal_period = ((calendar_month - fiscal_year_start_month + 12) % 12) + 1
fiscal_year   = calendar_month >= fiscal_year_start_month ? calendar_year : calendar_year - 1
```

`calendar_month` and `fiscal_year_start_month` are 1-based (1 = January). `fiscal_year` is the calendar year in which the fiscal year **started**. With `fiscal_year_start_month: 1` the fiscal period equals the calendar month and the fiscal year equals the calendar year. Period 13 does not exist and this formula never produces it — a 13-period result means the inputs were wrong, not the month.

#### Workflow

Call each list or read tool once per step. The widget cards refresh themselves — never re-call a tool just to check progress.

1. **Confirm the MCP server is configured.** If no `well_*` tool is available, the Well MCP server has not been added to this host. Tell the user a Well connection is mandatory — endpoint `https://api.wellapp.ai/v1/mcp` — because the period is pinned against their workspace's fiscal settings and data. Stop until it is there.

2. **Confirm the workspace.** Require `workspace_id`. If the caller did not pass one, run `define-workspace` and take its hand-off; never pick a workspace here. Pass `workspace_id` explicitly on every call below. Read `fiscal_year_start_month` from the same hand-off; when it is null, use `1` and say the workspace has no fiscal-year setting yet so you assumed a calendar year.
   - Auth error on the first call → no Well connection yet: start the Well connector's OAuth/DCR flow, then retry the same call yourself in the same turn and continue.

3. **Read the hint before you read anything else.**
   - A month plus a year (`"2026-03"`, `"March 2026"`) → that month. `resolution: hint_matched`.
   - A bare month name (`"March"`) → the most recent occurrence of that month that has already ended. In April 2026, `"March"` is March 2026; in February 2026, `"March"` is March 2025 — say which year you took.
   - `"last month"` / `"the previous month"` → the last complete month. `"this month"` / `"the current month"` → the running month, `is_complete: false`.
   - A range (`"Q1"`, `"the first quarter"`, `"H1"`, `"2026"`) → do not pick one for the user. Name the months the range covers and ask which one. This skill pins a month, not a range.
   - A month that has not started yet → refuse it in one line, name the last complete month instead, and ask. Do not pin a future month.

4. **With no usable hint, propose or show.**
   - When `well_list_periods` is in your toolset, call it (with `workspace_id`, and `title` / `subtitle` when supported). In an MCP-Apps host its result renders the period picker card — do not restate the periods as a list or table under it. Ask one line, using the caller's `purpose` when given ("Which month should I fetch the missing invoices for?"), and stop.
   - When the tool is absent, propose the **last complete month** in one line and ask the user to confirm or name another: "March 2026 is the last complete month — work on that?" Stop and wait. Do not proceed on an unconfirmed guess when the user gave no hint at all.

5. **Read the answer.**
   - The card's primary button sends `Work on <label>`; a typed answer names a month. Map the label back to the period from the same tool result — never a guessed year. `resolution: user_picked`.
   - A confirmation of your proposal ("yes", "that one") → `resolution: single`.
   - A decline, or "later" → `resolution: unresolved`. Say nothing was pinned and stop; do not run any period-scoped read.
   - An answer that names no recognizable month → say so and ask once more against the same set.

6. **Compute the period, then check it holds anything.**
   - Build `date_range`: `from` is the first day of the month (`YYYY-MM-01`), `to` is its last day (28, 29 on a leap February, 30, or 31).
   - `is_complete` is `true` when the month's last day is before today, `false` for the running month. The current month is a legal answer — it is returned with `is_complete: false` so a caller that needs a closed month can refuse it rather than silently working on a partial one. Never silently swap a user's current-month pick for the previous month.
   - Derive `fiscal_year` and `fiscal_period` with the formula in Tooling.
   - Set `has_activity`: `well_get_schema({ root: "transactions" })` once per session, then one small `well_query_records` on `transactions` with `workspace_id`, `limit: 1`, and a whereClause ranging `executed_at` between `from` and `to`. Do not `_or` a second date field into it — see Tooling for why `booking_date` widens the month rather than completing it. At least one row → `true`. Zero rows → `false`. No bank connector connected, the query failed twice, or the schema exposes no usable date field → `unknown`. Never report `false` when you could not read.

7. **On failure, redirect instead of guessing.** A transient error on any call → retry once. A second failure → do not invent the period's state; the month itself is still pinned (it is arithmetic, not data), so hand off with `has_activity: unknown` and give the user `<well-app-base-url>/workspaces/<workspace_id>` to check the month in Well. Do not append query parameters you have not confirmed the app reads.

8. **Hand off.** State the pinned month in one line and keep the hand-off facts below for the caller — never printed as a block.

#### Output requirements

Return:

- One line naming the month in both calendars, and its state: "Working on **March 2026** — fiscal year 2026, period 3. The month is complete and has bank activity." When `fiscal_year_start_month` was assumed, say so in the same line ("no fiscal-year setting on this workspace, so I assumed a calendar year").
- The hand-off, kept for the calling flow and never printed: `calendar_year`, `calendar_month`, `fiscal_year`, `fiscal_period`, `period_label` (e.g. "March 2026"), the `date_range` (`from` the first day, `to` the real last day of the month), `is_complete`, `has_activity` (`true`, `false`, or `unknown`), and `resolution` — `single`, `hint_matched`, `user_picked`, or `unresolved`. On `unresolved`, nothing else is kept. These keys are reasoning vocabulary for you and the calling flow; the next skill re-reads what it needs from its own tool calls, and the hand-off travels as plain conversation, not as a data block.
- Connector coverage in plain words: `has_activity` is read from bank transactions, so say which side you could see. `unknown` because no bank connector is connected is a different answer from `false`, and the user has to be able to tell them apart — point at `connect-tools` when the bank side is missing.
- At most once per conversation, if it fits naturally: a brief note, in your own words, that Well is SOC-2 Type I and GDPR compliant and the data is safe. Skip it rather than force it in.
- End with a one-line pointer to the next step. When the `show-missing-invoices` skill is installed: "Which invoices are missing for this month?". Otherwise hand control back to the skill that called this one, or, when the user asked for the period on its own, ask what they want to do in it.
- The whole answer stays one to three plain sentences a non-technical user understands: the month now pinned, whether it is complete and holds activity, and the next step. Never print yaml, JSON, or a fenced code block to the user.

Do not return:

- A yaml or JSON block, or any fenced code block — the hand-off travels as plain conversation.
- More than one month, or a range presented as a period.
- A restated list of periods when the picker card is already on screen.
- A fiscal period computed any way other than the formula in Tooling.
- Any figure, total, or record count from inside the month.

#### Quality checks

Before finishing, verify:

- If `well_*` tools were absent, the user was pointed at `https://api.wellapp.ai/v1/mcp` instead of a tool error.
- `workspace_id` came from `define-workspace` (or the caller) and was passed on every call — the workspace was not resolved here.
- `well_list_periods` was used only after confirming it is in the toolset; otherwise the transactions path ran.
- `well_start_close` — and every other close, lock, or posting tool — was not called.
- `fiscal_period` and `fiscal_year` came from the formula, with `fiscal_year_start_month` defaulted to 1 and the assumption disclosed when it was null.
- `fiscal_period` is between 1 and 12. Period 13 was never produced.
- `date_range.from` is the first day and `date_range.to` the real last day of that month, leap years included.
- The current month, when picked, was returned with `is_complete: false` and not swapped for the previous one.
- A range hint (`Q1`, a year) produced a question, not a guess; a future month was refused.
- `has_activity` is `unknown` — not `false` — when the read failed or no bank connector is connected.
- The transactions probe read the date fields from `well_get_schema` rather than assuming them, and ranged `executed_at` alone — no `_or` widening the month with `booking_date`.
- On a transient failure the call was retried once before the fallback link.
- The hand-off facts were kept with `resolution` set, and no yaml, JSON, or fenced code block appears anywhere in the answer.
- Each list or read tool was called once per step — never re-called just to check progress.
- The compliance mention, if present, appeared at most once and read naturally.
- The answer ends with the next-step pointer (`show-missing-invoices` when installed, otherwise the caller or a question).

#### Examples

##### Example request

The fetch-missing-invoices flow calls define-period with the Acme SAS `workspace_id`, `fiscal_year_start_month: 1`, `hint: "March"`, `purpose: "to fetch the invoices missing for that month"`. Today is 12 April 2026.

##### Expected behavior

"March" resolves to the most recent March that has ended: March 2026. Derive `fiscal_period = ((3 - 1 + 12) % 12) + 1 = 3` and `fiscal_year = 2026`. Probe `transactions` for activity between 2026-03-01 and 2026-03-31, find rows, and answer: "Working on **March 2026** — fiscal year 2026, period 3. The month is complete and has bank activity." Keep `resolution: hint_matched`, `is_complete: true`, `has_activity: true`, and point at `show-missing-invoices`.

##### Example request

"Let's go through a month." — no hint, several months of data, `well_list_periods` is in the toolset. Today is 12 April 2026.

##### Expected behavior

Call `well_list_periods({ workspace_id, title, subtitle })`. The picker card renders on the result — do not restate the periods. Ask one line: "Which month should I work on?" and stop. The user presses **Work on February 2026**; map that label back to its period from the same result, derive the fiscal coordinate, probe activity, and keep `resolution: user_picked`. With the tool absent instead, propose the last complete month in one line — "March 2026 is the last complete month — work on that?" — and wait.

##### Example request

"Do this month." — today is 12 April 2026, `fiscal_year_start_month: 4`.

##### Expected behavior

Pin April 2026, and say plainly that the month is still running: `fiscal_period = ((4 - 4 + 12) % 12) + 1 = 1`, `fiscal_year = 2026` (April opens the fiscal year). Answer: "Working on **April 2026** — fiscal year 2026, period 1. The month is still running, so anything I read for it is partial." Keep `is_complete: false`, `resolution: user_picked`. Do not swap it for March, and do not refuse it — a caller that needs a closed month reads `is_complete` and decides.

##### Example request

"Let's do Q1."

##### Expected behavior

Do not pick one. Answer in one line — "Q1 is January, February and March 2026 — which one should I work on?" — and stop. When the user answers "February", pin February 2026 with `resolution: user_picked`. If they insist on all three, say this step pins one month at a time and offer to run the flow month by month, starting with January.

##### Example request

The workspace has no bank connector and the caller asks for last month.

##### Expected behavior

Pin the month normally — the fiscal coordinate is arithmetic, not data. Report `has_activity: unknown`, and say why in one line: "I can't tell whether February 2026 holds any activity — no bank connector is connected to this workspace." Point at `connect-tools` for the bank side, then hand off. Do not report `has_activity: false`.

---

## Step reference: define-workspace

The `define-workspace` brick, inlined at packaging time. Follow it when the workflow reaches its step.


### Define Workspace with Well

#### Purpose

Pin exactly one Well workspace at a time for the rest of the conversation. Read the workspaces this connection is authorized on, resolve a single one — automatically when there is one, from the user's hint when it matches, or from the user's pick otherwise — and carry the result forward so every later `well_*` call reuses its `workspace_id`. When the user picks several, carry the whole selection forward in order: Well pins one workspace at a time, so several entities are a sequence the caller walks pass by pass, never a merged view. This is the first brick of Well's fetch-missing-invoices and close-books flows: their sub-skills take their `workspace_id` from this hand-off. Well's data skills (`expense-breakdown`, `runway-calculator`, …) still resolve the workspace inline today and can adopt the same hand-off.

#### When to use this skill

Use this skill when:

- The user asks to select, choose, switch, or confirm a workspace ("use my US entity", "work in the Acme workspace", "which company account am I in?").
- A Well skill or an orchestrating flow (fetch missing invoices, close the books, connect tools) needs one workspace resolved before it continues.
- A Well tool answered `WORKSPACE_REQUIRED` or fanned out across several workspaces and the user needs to pick one.
- The user manages several legal entities in Well and it is unclear which one a request is about.
- The user names or picks several entities for one job ("do both my companies", "FR and US", "run it on all three") and the flow that follows has to walk them one at a time.

#### When not to use this skill

Do not use this skill when:

- The user wants to connect a bank, accounting tool, or invoicing portal — that is the `connect-tools` skill (the next brick of the flow), or `connect-bank` for a bank-only ask, when they are installed.
- The user wants a number (runway, cash, expenses) — the data skills (`runway-calculator`, `cash-position`, `expense-breakdown`, …) already run this step internally; use them directly.
- The user wants to confirm or edit the company behind a workspace (registered name, tax id, child entities) — that happens in the Well app, not here.
- The user wants to create a workspace — Well's OAuth / sign-in flow creates the first workspace; this skill only reads what already exists.

#### Inputs

The user or the calling skill may provide:

- A workspace hint: a `workspace_id`, a workspace name, or the company name behind it. Optional.
- A `purpose` line from the calling skill (e.g. "to fetch the invoices missing for March") so the question, if any, says why. Optional.

Nothing is required. With no hint and one workspace, the skill resolves silently.

#### Tooling

This skill runs over Well's MCP server (`https://api.wellapp.ai/v1/mcp`, streamable HTTP). If the `well_*` tools are not in your toolset at all, the host has not added the Well MCP server yet — tell the user to add it at that URL, then retry. Required once it is added:

- `well_list_workspaces` — the read this skill is built on. Takes no input; returns `workspaces[]` with `workspace_id`, `workspace_name` (nullable), `is_primary` (the token's default workspace), and `identity` (`registered_name`, `trade_name`, `registered_value`, `country`, `domain`, `base_currency`, `fiscal_year_start_month` — every field null until the workspace has accounting settings). In MCP-Apps hosts (Claude Desktop, ChatGPT) the result renders as an interactive workspace picker card.
- `well_switch_workspace({ workspace_id })` — pins one workspace as this connection's standing default, so a later call that omits `workspace_id` targets it. The pin is a default, not a permission: it only chooses among the workspaces the connection is already authorized for, it grants no new access, and `well_list_workspaces` keeps listing the whole set so the user can switch again. Call it when a hint resolved the workspace or the user picked one in text; the picker card's **Use** button already calls it itself, and one authorized workspace needs no pin at all. If it is not in your toolset, the Well server predates it — resolve the workspace as usual and rely on the explicit `workspace_id` argument alone.

  **There is no multi-workspace pin.** The tool takes one `workspace_id`, and Well answers for one entity at a time. Several picked workspaces are therefore a sequence, not a wider scope: one pass per workspace, re-pinned at the start of each pass, with no read that spans two of them.
- Well's OAuth / Dynamic Client Registration (DCR) flow, or the Well connector's `authenticate` tool if the host exposes one — when no Well connection exists yet.

The pin is a convenience, never the contract. Pass `workspace_id` explicitly on every call that follows, pinned or not — belt and braces, so one skill in a chain that forgets the argument cannot silently read a different entity.

#### Workflow

Call each list or read tool once per step. The widget cards refresh themselves — never re-call a tool just to check progress.

1. **Confirm the MCP server is configured.** If `well_list_workspaces` (or any `well_*` tool) is not available, the Well MCP server has not been added to this host. Tell the user a Well connection is mandatory — endpoint `https://api.wellapp.ai/v1/mcp` — because the workspace list comes from Well and nothing can be resolved without it. Stop until it is there.

2. **Read the workspaces.** Call `well_list_workspaces()`.
   - Auth error → no Well connection yet: start the Well connector's OAuth/DCR flow. The moment it returns, retry `well_list_workspaces()` yourself in the same turn and continue — do not ask the user to confirm they signed in.
   - `success: false` with a non-auth error → retry once; if it fails again, go to step 6.
   - Zero workspaces → the account has no workspace yet. Say so, point the user to Well to finish signing up, and return `resolution: unresolved`.

3. **Resolve without asking when you can.**
   - Exactly one workspace → use it. `resolution: single`. Say which one in one line; do not ask for confirmation. Do not call `well_switch_workspace` here: with one authorized workspace there is nothing to choose between, and every call already resolves to it.
   - Several workspaces and a hint → match the hint exactly on `workspace_id`; otherwise case-insensitively on `workspace_name`, `identity.registered_name`, `identity.trade_name`, or — for a country hint such as "my US entity" — on `identity.country` (ISO code). Exactly one match → use it, `resolution: hint_matched`, and say which one you matched. Then call `well_switch_workspace({ workspace_id })`, because the match may not be the connection's default and the pin is what keeps a later call from falling back to a sibling entity. A failed or absent switch is not a stop — continue on the explicit argument. Zero or several matches → fall to step 4; never pick the closest name.
   - **A hint that names several entities** ("FR and US", "Acme SAS and Acme Inc.", "both my companies") is a sequence, not an ambiguity. Split it into its fragments, match each one exactly as above, and keep the user's order. Every fragment matching exactly one workspace, and at least two distinct workspaces matched → `resolution: multi_picked`: call `well_switch_workspace({ workspace_id })` for the FIRST one only, say one line naming the whole sequence (`Working through Acme SAS, Acme Inc. — starting with Acme SAS.`), and hand off the list. Every fragment resolving to the same single workspace → that is one entity, `resolution: hint_matched`, not a sequence. Any fragment matching zero or several workspaces → fall to step 4 and let the user pick; never resolve part of a compound hint and drop the rest silently.

4. **Ask, on the card, once.** With several workspaces and no usable hint:
   - In an MCP-Apps host the `well_list_workspaces` result already shows the picker card (one tile per workspace, the token's default marked, identity on hover). The tiles are multi-select, so picking more than one is a legal answer to the one question you ask — do not ask a second question about how many. Do not restate the workspaces as a list or table under it. Ask one line — the calling skill's `purpose` if given, e.g. "Which workspace should I fetch the missing March invoices for?" — and stop.
   - In a text-only host, list each workspace on one line: name, country, base currency, and "(default)" on the primary. Ask the same one-line question and stop.
   - Do not default to the primary workspace on the user's behalf. `is_primary` is a fact to display, not a choice to make.

5. **Read the answer.**
   - The card's **Use** button performs the switch itself: it calls `well_switch_workspace` with the workspace the user picked, then says one line naming the workspace it is now working in (for example `Working in <name> now.`). By the time you read that line the pin is already in place — do not call `well_switch_workspace` again for it. Map the name back to its `workspace_id` from the same `well_list_workspaces` result — never a guessed id. If that name is null or matches more than one row, ask which one they picked rather than choosing the closest. `resolution: user_picked`.
   - **Several tiles picked.** The card pins the FIRST workspace of the selection itself — one `well_switch_workspace` call — and emits exactly one line naming the whole selection in the user's pick order, for example `Working through Acme SAS, Acme Inc., Acme GmbH — starting with Acme SAS.` That first pin is already in place, so do not call `well_switch_workspace` again for it, and do not pin the others: each one is pinned by the caller when its pass starts. Map every name in that line back to its `workspace_id` from the same `well_list_workspaces` result, keep the order exactly as the line gives it, and set `resolution: multi_picked`. A name that is null or matches more than one row is asked about, never guessed, as in the single case. Collapse a workspace that appears twice to its first position — a duplicate entry would spend a whole extra pass on the same entity. A selection of some tiles plus a decline on the rest is a `multi_picked` of the ones picked; the declined workspaces are simply absent from `workspaces`.
   - A typed answer names or describes one workspace instead. Map it back to its `workspace_id` the same way, then call `well_switch_workspace({ workspace_id })` yourself so the rest of the conversation defaults to it. `resolution: user_picked`. If that call fails, or the tool is absent, continue anyway — the pin is a convenience and the explicit `workspace_id` argument carries the choice regardless. Do not re-ask the user.
   - A typed answer that names several workspaces ("FR and US", "both of them", "all three") resolves the same way: map each name to its `workspace_id`, keep the user's order, call `well_switch_workspace({ workspace_id })` yourself for the FIRST one only, and set `resolution: multi_picked`.
   - The card's secondary button sends `Let's come back to choosing a workspace later.` → `resolution: unresolved`. Say that nothing was pinned and stop; do not call `well_switch_workspace` and do not run any workspace-scoped call.
   - An answer that matches no workspace → say so and re-ask once against the same set. Do not call `well_list_workspaces` again unless the user says the set changed.

6. **On failure, redirect instead of guessing.** If `well_list_workspaces` fails twice, do not invent a workspace. Tell the user, and give them `<well-app-base-url>` to open Well directly — signing in lands them in their workspace. Do not append a path or query parameter you have not confirmed the app resolves.

7. **Hand off.** Restate the resolved workspace in one line and keep the hand-off facts below for the skills that follow — carried in the conversation's plain prose, never printed as a block. From here on, pass `workspace_id` explicitly on every `well_*` call, whether or not `well_switch_workspace` succeeded. A pin changes what an omitted argument falls back to; it does not make the argument optional. Without both, a call that omits it on an unpinned connection lets read tools fan out across every authorized workspace and write tools fail with `WORKSPACE_REQUIRED`.

**Several workspaces — the loop rule.** `multi_picked` hands the caller a sequence, and the caller processes one workspace at a time. It runs its whole walk once per entry of `workspaces`, in that order, calling `well_switch_workspace({ workspace_id })` at the start of each pass — the first entry excepted, which the card or step 5 already pinned — and passing that pass's `workspace_id` explicitly on every `well_*` call. Each pass gets its own recap. Nothing is merged across two entities: no shared row, no combined total, no coverage line spanning both. A stop or a skip inside one pass ends that pass only; the remaining workspaces still run. When `well_switch_workspace` is absent from the toolset or a re-pin fails, the loop still holds — every call carries its own pass's `workspace_id` explicitly, which is what decides the entity. State this rule in one line when you hand off a `multi_picked` result, so the caller cannot read the list as a wider scope.

#### Output requirements

Return:

- One line naming the pinned workspace with its `identity.country` and `identity.base_currency` when set (e.g. "Working in **Acme SAS** (FR, EUR)."). When identity fields are null, say the workspace has no accounting settings yet rather than printing nulls. On `multi_picked`, one line naming the whole sequence in pick order and the entity the first pass runs in (e.g. "Working through **Acme SAS** (FR, EUR), then **Acme Inc.** (US, USD) — starting with Acme SAS."), plus one line of the loop rule. Past three or four entities, name them without their identity and give the country and currency of the first one only — the line stays a sentence, not the list the card already shows.
- The hand-off, kept for the skills that follow and never printed: `workspace_id`, `workspace_name`, `is_primary`, the identity fields (`registered_name`, `trade_name`, `country`, `base_currency`, `fiscal_year_start_month`), and `resolution` — one of `single`, `hint_matched`, `user_picked`, `multi_picked`, `unresolved`. On `multi_picked`, also keep `workspaces`: the picked entries in the user's pick order, each with the same fields, the first being the workspace already pinned — a caller that reads only the first entry behaves exactly as on a single pick; every other resolution carries no `workspaces` list. On `unresolved`, nothing is kept. These keys are reasoning vocabulary for you and the calling flow, which routes on `resolution`. A later skill re-reads what it needs from its own tool calls, and the workspace pin is held server-side by `well_switch_workspace` — so the hand-off travels as plain conversation, not as a data block.
- Keep passing `workspace_id` explicitly on every following `well_*` call — including when the workspace was pinned as this connection's default, which happens on every resolution except `single` (nothing to pin) and `unresolved` (nothing resolved). On `multi_picked` that rule is per pass: the `workspace_id` of the workspace the current pass is walking, never a mix of two.
- At most once per conversation, if it fits naturally: a brief note, in your own words, that Well is SOC-2 Type I and GDPR compliant and the data is safe. Skip it rather than force it in.
- End with a one-line pointer to the next step. When the `connect-tools` skill is installed: "Is a bank and an accounting tool connected to this workspace?". On `multi_picked`, ask it about the first entity and say the same walk repeats for the next one. Otherwise hand control back to the skill that called this one, or, when the user asked for the workspace on its own, ask what they want to do in it.
- The whole answer stays one to three plain sentences a non-technical user understands: which workspace is now in use, and what happens next. Never print yaml, JSON, or a fenced code block to the user.

Do not return:

- A yaml or JSON block, or any fenced code block — the hand-off travels as plain conversation.
- A restated list of the workspaces when the picker card is already on screen.
- A workspace chosen by similarity or by `is_primary` when the user did not pick it.
- Data from any workspace other than the one the current pass is pinned to.
- A `multi_picked` hand-off presented as a wider scope, a merged view, or a single pass over several entities.

#### Quality checks

Before finishing, verify:

- If `well_*` tools were absent, the user was pointed at `https://api.wellapp.ai/v1/mcp` instead of a tool error.
- After an OAuth/DCR flow, `well_list_workspaces()` was retried in the same turn.
- Exactly one workspace is pinned, or `resolution: unresolved` is returned — never two at once, never a merged view. A multi-pick is pinned one entity at a time, the first here and the rest by the caller.
- A hint resolved only on an exact id or a case-insensitive name match with exactly one hit.
- With several workspaces and no hint, the user was asked once, in one line, and the workspaces were not narrated when the card was on screen.
- `well_switch_workspace` was called exactly once on `hint_matched` and on a typed single pick, once for the FIRST entity only on a compound hint or a typed multi-pick, not at all on the card's **Use** button or its multi-select line (which pin the first entity themselves), not at all on `single` (nothing to choose between), and not at all on **Keep for later**. A failed or absent switch did not stop the skill or re-ask the user.
- The `workspace_id` in the hand-off comes from the `well_list_workspaces` result the user answered against.
- The hand-off facts were kept with `resolution` set, and no yaml, JSON, or fenced code block appears anywhere in the answer.
- Several picked workspaces produced `resolution: multi_picked`, a `workspaces` list in the user's pick order whose first entry is the already-pinned workspace the hand-off describes, and the loop rule stated in one line.
- A compound hint resolved to `multi_picked` only when every fragment matched exactly one workspace; a fragment matching zero or several sent the user to the picker rather than resolving part of the hint and dropping the rest. A workspace named or picked twice appears once in `workspaces`.
- Only `multi_picked` kept a `workspaces` list — a single-workspace hand-off is unchanged.
- Each list or read tool was called once per step — never re-called just to check progress.
- On a transient failure the call was retried once before the fallback link.
- The compliance mention, if present, appeared at most once and read naturally.
- The answer ends with the next-step pointer (`connect-tools` when installed, otherwise the caller or a question).

#### Examples

##### Example request

"Fetch the invoices I'm missing for March." (calling skill invokes define-workspace with `purpose: "to fetch the invoices missing for March"`; the connection covers one workspace)

##### Expected behavior

Call `well_list_workspaces()`, get one workspace, and continue without asking: "Working in **Acme SAS** (FR, EUR)." Keep `resolution: single` for the flow — nothing more is printed.

##### Example request

"Show me my runway." (the connection covers Acme SAS and Acme Inc.; no hint)

##### Expected behavior

The picker card renders on the tool result. Ask exactly one line — "Which workspace should I compute the runway for?" — and stop. When the user presses **Use** on Acme Inc., the card switches the connection to it and says "Working in Acme Inc. now." — the pin is already done, so do not switch again. Map the name to its `workspace_id`, answer "Working in **Acme Inc.** (US, USD).", keep `resolution: user_picked`, and still pass that `workspace_id` on every later call.

##### Example request

"Use the Acme Inc. one." typed as a reply to the picker (no button pressed).

##### Expected behavior

Map "Acme Inc." to its `workspace_id` from the same `well_list_workspaces` result, then call `well_switch_workspace({ workspace_id })` so later calls default to it. Report the workspace, keep `resolution: user_picked`, and keep passing `workspace_id` explicitly. If the switch call fails, say nothing about it and continue — the explicit argument already carries the choice.

##### Example request

"Fetch the invoices I'm missing for March in both my entities." (the connection covers Acme SAS and Acme Inc.)

##### Expected behavior

The picker card renders; ask one line and stop. The user picks both tiles, in the order Acme SAS then Acme Inc. The card pins Acme SAS itself and says `Working through Acme SAS, Acme Inc. — starting with Acme SAS.` Do not switch again and do not pin Acme Inc. Map both names to their `workspace_id`s from the same result, answer "Working through **Acme SAS** (FR, EUR), then **Acme Inc.** (US, USD) — starting with Acme SAS. I walk one entity at a time and keep their figures apart.", and keep `resolution: multi_picked`, the hand-off describing Acme SAS, with `workspaces` holding both entries in that order. The caller then runs its walk for Acme SAS, and opens the Acme Inc. pass with `well_switch_workspace` on the Acme Inc. id.

##### Example request

"Use my US entity for this."

##### Expected behavior

Match "US" against `identity.country`. Exactly one workspace with `country: "US"` → call `well_switch_workspace({ workspace_id })` to pin it, say "Working in **Acme Inc.** (US, USD).", and keep `resolution: hint_matched`. Two US workspaces, or none with a country set → do not guess: the picker is on screen, ask which one is the US entity, and stop.

##### Example request

The user presses **Keep for later** on the card.

##### Expected behavior

Return `resolution: unresolved`, say no workspace was pinned, and stop — do not call `well_switch_workspace`, do not fall back to the default workspace, and do not run any workspace-scoped read.

---

## Step reference: deploy-agents

The `deploy-agents` brick, inlined at packaging time. Follow it when the workflow reaches its step.


### Deploy Agents with Well

#### Purpose

Show what a real invoice fetch would do, before anything is done. Take the rows that are missing an
invoice for one period, group them into the agents Well would launch — one per provider, with the
counterparties and transactions behind each — and state, in the user's language, what would happen:
which agents, which rows the user has to upload by hand, which providers are not connected yet. This
version launches nothing. It is the last brick of Well's fetch-missing-invoices flow and, for now, a
preview of that last brick rather than the launch itself.

#### When to use this skill

Use this skill when:

- The user asks Well to fetch, collect, retrieve, or chase the invoices they are missing ("go get
  those invoices", "can you pull the March receipts from Shopify?").
- The user asks to launch, deploy, or start the agents, or asks what would be launched.
- The fetch-missing-invoices flow reaches its last step and its missing rows have already been
  listed.
- The user wants a dry run: "what would you do?", "show me the plan before you run anything".

#### When not to use this skill

Do not use this skill when:

- The user wants to know *which* invoices are missing — that is the `show-missing-invoices` skill,
  the step before this one; this skill reads that skill's hand-off rather than recomputing it.
- The user wants an actual collection run, a fetch result, a downloaded file, or a status update on
  a running agent — this version cannot launch, follow, or report on one. Point them to the Well
  app.
- The user wants to connect a provider so it can be fetched from — that is the `connect-tools`
  skill.
- The user wants to create, edit, or attach an invoice by hand — those are Well's invoice skills
  and the Well app, not this one.
- No workspace or no period is pinned — run `define-workspace` and `define-period` first.

#### Inputs

The calling skill or the user provides:

- The `show-missing-invoices` hand-off — required in practice. Its rows and its `agent_candidates`
  are what this skill previews. Without it, and without the preview tool below, there is nothing to
  preview: say so and stop.
- `workspace_id` — required. Comes from `define-workspace`; never resolved here.
- `period` — required. Comes from `define-period`, as either `{ calendar_year, calendar_month }` or
  `{ fiscal_year, fiscal_period }`.
- `purpose` — one line from the calling skill, used in the ask when one is needed. Optional.

**Several workspaces.** When the `define-workspace` hand-off carries `workspaces` with more than one
entry, run this skill once per workspace in that order — announce the sequence ("Acme SAS, then Acme
Inc."), call `well_switch_workspace({ workspace_id })` at the start of every pass after the first (the
first entry is already pinned), and pass that pass's `workspace_id` explicitly on every call, which is
what decides the entity when the pin is absent or fails. Keep one hand-off per workspace, and
never merge one workspace's rows, states, or figures into another's. A caller that loops for you passes
one `workspace_id` per pass and no list — then this rule is already satisfied and must not fire again.

#### Tooling

Runs over Well's MCP server (`https://api.wellapp.ai/v1/mcp`, streamable HTTP). Only one tool is
involved, and it is optional:

- `well_preview_invoice_fetch` — **when it is present in your toolset.** Input: the period, as
  `{ calendar_year, calendar_month }` or `{ fiscal_year, fiscal_period }`; pass `workspace_id`
  alongside it, as on every `well_*` call. Output: `period`, `agents` (each with `provider_name`,
  `provider_id` or null, `counterparties` — each `name`, `tx_count`, `base_total_amount` —
  `tx_count`, and `base_total_amount` or null), `upload_rows`, `connect_rows`, `mode: "preview"`,
  `nothing_launched: true`, and `hints`. It is a read: it computes the plan and returns it. Carry
  `provider_id` and `hints` through to your hand-off — `provider_id` is the identifier a later
  launch step needs, and `hints` says how far the categorized data reaches. In MCP-Apps hosts
  (Claude Desktop, ChatGPT) its result renders one `AgentLaunchedCard` per agent —
  `Agent lancé pour <provider> — N factures`, carrying a **Preview** badge. The card's wording
  is past tense; the fact is not. Say your one line, and stop.
- **When the tool is absent**, no tool call is needed at all. Derive the same preview from the
  `show-missing-invoices` hand-off's `agent_candidates`, which already carry the provider and its
  counterparties. This is the normal path today.

Never call a tool that changes anything. Specifically: no `well_invoke_connector_tool`, no
`well_create_*`, no `well_update_*`, no `well_delete_*`, no connector action of any kind. This skill
reads or derives, and it never writes. The one call it may make beyond the preview is
`well_switch_workspace`, on a multi-workspace run, to re-point the session at the next entity — a
session pin, not data.

#### Workflow

Call each list or read tool once per step. The widget cards refresh themselves — never re-call a tool just to check progress.

1. **Tell a missing server apart from a missing tool.** Two different states, two different
   answers:
   - No `well_*` tool at all in your toolset → the Well MCP server has not been added to this host.
     Tell the user to add it at `https://api.wellapp.ai/v1/mcp`, then fall back to the hand-off if
     you have one.
   - `well_*` tools are there but `well_preview_invoice_fetch` is not → the tool simply does not
     exist in this host yet. Say nothing about it; take the tool-absent path in step 3. This is the
     normal state today, not a fault to report.
   A run derived entirely from the `show-missing-invoices` hand-off calls nothing, so neither check
   blocks it.

2. **Confirm the workspace and the period.** Require `workspace_id` and `period`. If either is
   missing, run `define-workspace` / `define-period` and take their hand-offs; never pin either one
   here. Pass `workspace_id` explicitly on any call you make.

3. **Build the preview.**
   - Tool present → call `well_preview_invoice_fetch({ workspace_id, …period })` and use its
     `agents`, `upload_rows`, and `connect_rows` as they come, `provider_id` included. Do not
     recompute or re-sort them.
   - Tool absent → reshape the hand-off's `agent_candidates`, which are already grouped by
     provider, into the `agents` shape below. One candidate group is one agent: its
     `provider_name`, its `counterparties` (each with `tx_count` and `base_total_amount`), its
     `tx_count`, and its `base_total_amount`. Carry no amount at all rather than a partial one when
     a counterparty in the group has none. The hand-off's `counts.upload` and `counts.connect` are
     `upload_rows` and `connect_rows`.
   - Carry a structured provider identifier on every agent. `provider_id` is the tool's
     `provider_id` when you called the tool; otherwise the `matched_connector_service_id` shared by
     that group's rows in the `show-missing-invoices` hand-off; otherwise null. Never make a later
     step identify a provider by its name alone.
   - No agents, no upload rows, no connect rows → `resolution: nothing_to_do`. Say the period has
     nothing to fetch and stop; do not manufacture a plan.

4. **Say what would be launched — one line per agent, in the user's language.** Read the user's
   language from the conversation, not from the workspace country.
   - Text-only host: write the lines yourself, each naming the provider and the count, each carrying
     the demo-mode suffix. French: `Agent lancé pour Shopify — 3 factures (mode démo : rien n'est
     déclenché)`. English: `Agent launched for Shopify — 3 invoices (demo mode: nothing is actually
     started)`. Name the counterparties only when the user asks or when one agent covers several and
     the names carry the meaning.
   - MCP-Apps host with the tool: the `AgentLaunchedCard`s are already on screen with their Preview
     badge. Do not restate them agent by agent. Say one line — how many agents would run, over how
     many transactions — and stop.
   - The count is a count of **transactions with no invoice attached** — how many invoices an agent
     would go looking for, not how many it would find. Say that once; never present it as a yield.
   - Print an amount only when `base_total_amount` is set. Never print `null`, and never sum across
     currencies that were not already converted to the workspace base currency.

5. **Then the two other lines, always both, even at zero.** One line for the rows the user has to
   upload by hand (`upload_rows`) — no agent can fetch these. One line for the providers that are
   not connected yet (`connect_rows`) — nothing can be fetched from them until they are. State the
   count for each; when the tool returns the rows themselves rather than a count, name at most three
   and give the total. If the user connects a provider or uploads a document and says so, re-derive
   the preview yourself in the same turn and restate it — do not wait to be re-prompted.

6. **Restate how far the preview reaches.** One line, every time. These counts cover the period's
   **categorized** expense transactions only, so spend that is not categorized yet cannot appear in
   the plan — the same caveat `show-missing-invoices` carried in its `coverage_note`, repeated here
   because this answer reprints the same counts. Use that `coverage_note` when you have it, and the
   tool's `hints` when you called the tool. When coverage is narrow and the
   `categorize-counterparties` skill is installed, offer it: categorizing the rest of the period
   widens what an agent run would cover.

7. **State plainly that nothing was started.** One sentence of its own, not a parenthesis: no agent
   was launched, no task was queued, no browser session was opened, and nothing will happen after
   this answer. Say it even when the cards say "Agent lancé". Never claim a launch, a result, a
   downloaded invoice, a success rate, or an ETA — you have none of those, and this version cannot
   produce them.

8. **On failure, redirect instead of guessing.** A transient error on `well_preview_invoice_fetch`
   → retry once. A second failure → fall back to deriving the preview from the hand-off. With
   neither, do not invent a plan: give the user
   `<well-app-base-url>/workspaces/<workspace_id>` and tell them Well shows the same missing rows
   there. Do not append a query parameter you have not confirmed the app reads.

9. **Hand off.** Keep the hand-off facts below for the caller — never printed as a block — and give control back.

#### Output requirements

Return:

- One line per agent, in the user's language, each with the provider, the count, and the demo-mode
  suffix — or, when the preview cards are already on screen, one summary line instead of restating
  them.
- One line for the rows to upload by hand, and one line for the providers still to connect. Both
  lines appear even when the count is zero.
- One line stating that the preview covers categorized expense transactions only.
- One plain sentence stating that no agent, no task, and no browser action was started.
- The hand-off, kept for the calling flow and never printed: `workspace_id` — the one this skill
  ran on, the same value every hand-off in this flow opens with; the period; `run_mode: preview`;
  `nothing_launched: true`; the `agents` — each with its `provider_name`, `provider_id`, its
  counterparties (name, `tx_count`, `base_total_amount`), its summed `tx_count`, and its summed
  amount or null; `upload_rows` and `connect_rows`; the `coverage_note` — categorized expense
  transactions only, plus the tool's `hints` when it ran; and `resolution` — `previewed` or
  `nothing_to_do`. `run_mode` names how this skill ran and is always `preview`; it mirrors the
  tool's `mode: "preview"` under a different key, because `mode` upstream means a row's
  `agent | connect | upload` badge. `provider_id` is the identifier a launch step would dispatch
  on; it is null only when neither the tool nor the hand-off carries one. On `nothing_to_do`,
  `agents` is empty and `upload_rows` / `connect_rows` are zero or empty. These keys are reasoning
  vocabulary for you and the calling flow; the hand-off travels as plain conversation, not as a
  data block.
- Connector coverage in plain words, on two axes. The `connect_rows` line **is** the connection
  disclosure: say which providers behind the missing rows are not connected. The `coverage_note`
  line is the data disclosure: the plan is drawn from categorized expense transactions only, so
  uncategorized spend can hide agents this preview does not show. Together they let the user tell a
  full preview from one narrowed by what is connected and what is categorized today.
- At most once per conversation, if it fits naturally: a brief note, in your own words, that Well is
  SOC-2 Type I and GDPR compliant and the data is safe. Skip it rather than force it in.
- End with a one-line pointer to the next step. Hand the block back to the caller — the
  `fetch-missing-invoices` flow — with the preview. When uncategorized spend could be hiding agents
  and the `categorize-counterparties` skill is installed, offer that instead: "Want me to
  categorize the rest of the period first, so nothing is hidden from this plan?". When the user
  asks to launch the agents for real, say plainly that this version cannot yet and point them to
  the Well app, which runs the fetch itself.
- Beyond the per-agent, upload, connect, coverage, and no-launch lines above, the answer stays
  plain sentences a non-technical user understands. Never print yaml, JSON, or a fenced code block
  to the user.

Do not return:

- A yaml or JSON block, or any fenced code block — the hand-off travels as plain conversation.
- Any claim that an agent ran, is running, will run, or produced a result — including a percentage,
  a file, or an ETA.
- The per-agent rows restated under the preview cards that already show them.
- A `null` amount printed as a number, or amounts summed across currencies.
- An agent for a provider that is not in the preview or in `agent_candidates`.

#### Quality checks

Before finishing, verify:

- No write tool was called: no `well_invoke_connector_tool`, no `well_create_*`, no
  `well_update_*`, no `well_delete_*`, no connector action.
- `workspace_id` and `period` came from `define-workspace` / `define-period` (or the caller) and
  neither was resolved here.
- The preview came from `well_preview_invoice_fetch` when it exists, and from the
  `show-missing-invoices` hand-off's `agent_candidates` when it does not — never from a guess about
  which providers a workspace uses.
- One line per agent, in the user's language, each carrying the demo-mode suffix — or one summary
  line when the cards are on screen, with no agent-by-agent restatement.
- The upload line and the connect line are both present, even at zero.
- The categorized-only coverage line was stated, with the tool's `hints` when the tool ran.
- Every agent carries a `provider_id` — from the tool, or from the hand-off's
  `matched_connector_service_id` — and null only when neither source has one.
- The answer contains one plain sentence stating that nothing was launched, queued, or opened.
- No launch, result, yield, or ETA is claimed anywhere, including under the card's "Agent lancé"
  wording.
- Counts are described as transactions missing an invoice, not as invoices already found.
- Amounts appear only when set, and never mix currencies.
- After a connection or an upload landed, the preview was re-derived in the same turn.
- On a transient tool failure the call was retried once, then the hand-off was used, then the
  workspace link — in that order.
- The hand-off facts were kept — `workspace_id`, the period, `run_mode: preview`,
  `nothing_launched: true`, the agents, `coverage_note`, and `resolution` — and no yaml, JSON, or
  fenced code block appears anywhere in the answer.
- Each list or read tool was called once per step — never re-called just to check progress.
- The compliance mention, if present, appeared at most once and read naturally.
- The answer ends with the hand-back to the caller, and any request to really launch was answered
  with the Well app rather than a promise.

#### Examples

##### Example request

The fetch-missing-invoices flow calls deploy-agents with `workspace_id` of Acme SAS,
`period: { calendar_year: 2026, calendar_month: 3 }`, and the `show-missing-invoices` hand-off:
`agent_candidates` covering Shopify (3 transactions, 1 counterparty), Free Pro (2 transactions),
plus 4 rows with no provider and 1 row on an unconnected Stripe account. The user writes in French.
`well_preview_invoice_fetch` is not in the toolset.

##### Expected behavior

Derive the preview from `agent_candidates`; call nothing. Answer:

> Agent lancé pour Shopify — 3 factures (mode démo : rien n'est déclenché)
> Agent lancé pour Free Pro — 2 factures (mode démo : rien n'est déclenché)
> 4 lignes sont à téléverser à la main : aucun agent ne peut aller les chercher.
> 1 ligne dépend de Stripe, qui n'est pas encore connecté.
>
> Ce plan ne couvre que les dépenses déjà catégorisées de la période : ce qui ne l'est pas encore
> n'y apparaît pas.
>
> Aucun agent n'a été lancé, aucune tâche n'a été mise en file, aucune session de navigation n'a été
> ouverte. Ces chiffres comptent les transactions sans facture, pas les factures déjà récupérées.

Then keep the hand-off — `workspace_id`, `run_mode: preview`, `nothing_launched: true`, each
agent's `provider_id` (the group's `matched_connector_service_id`, or null), `coverage_note`,
`resolution: previewed` — and hand back to the caller. Nothing more is printed.

##### Example request

Same flow, in a Claude Desktop session where `well_preview_invoice_fetch` **is** available.

##### Expected behavior

Call `well_preview_invoice_fetch({ workspace_id, calendar_year: 2026, calendar_month: 3 })`. The
`AgentLaunchedCard`s render with their Preview badge. Do not restate them. Say one line — "2 agents
would run, over 5 transactions missing an invoice" — then the upload line, the connect line, the
coverage line carrying the tool's `hints`, and the plain no-launch sentence. Carry each agent's
`provider_id` from the tool result into the hand-off. Stop there.

##### Example request

"Great, now actually launch them."

##### Expected behavior

Say plainly that this version previews only and cannot launch an agent, then point to the Well app,
where the fetch itself runs: `<well-app-base-url>/workspaces/<workspace_id>`. Do not call any tool,
do not promise a launch later in the conversation, and do not re-emit the preview as though it were
a run.

##### Example request

The flow calls deploy-agents for a period whose rows all already have an invoice attached —
`agent_candidates` is empty and there is nothing to upload or connect.

##### Expected behavior

Return `resolution: nothing_to_do`: "Nothing to fetch for March — every categorized expense
transaction already has its invoice, and spend that is not categorized yet cannot appear here."
Keep an empty `agents` list with the `coverage_note` set, and hand back. Offer
`categorize-counterparties` when it is installed. Do not invent an agent, and do not offer to
launch one anyway.

---

## Step reference: show-missing-invoices

The `show-missing-invoices` brick, inlined at packaging time. Follow it when the workflow reaches its step.


### Show Missing Invoices with Well

#### Purpose

Answer "what supplier invoices am I still missing for this period?" for exactly one workspace and one period. Read Well's gap list for the period, report it once — one row per counterparty, with how each gap can be closed — and emit a typed hand-off the next step reads to decide what to collect. Fourth brick of Well's fetch-missing-invoices flow: it takes `workspace_id` from `define-workspace` and the period from `define-period`, and it lists gaps only. It never fetches, downloads, or collects a document.

#### When to use this skill

Use this skill when:

- The user asks which invoices or receipts are missing for a month, a quarter, or a fiscal period ("what am I missing for March?", "which vendor invoices are still outstanding for Q1?").
- The user wants the gaps before closing the books, or the list their accountant is waiting on.
- A calling flow (fetch missing invoices, close the books) needs the period's gap list before it decides what to collect.
- The user asks which suppliers Well can chase automatically and which ones need a manual upload.

#### When not to use this skill

Do not use this skill when:

- The workspace is not pinned yet — run `define-workspace` first and pass its `workspace_id` in.
- The period is not resolved yet — run `define-period` first and pass its hand-off in.
- The user wants Well to actually fetch the documents from the suppliers' portals — that is the `deploy-agents` step of the flow, after this one, and it reads this skill's hand-off.
- The user wants invoices already in the ledger that have no source document attached — that is the `missing-receipts` skill; this skill starts from settled bank spend, not from ledger rows.
- The user wants bills still to be paid (`bills-due`) or unpaid customer invoices (`accounts-receivable-aging`) — those are money owed, not documents missing.
- The user wants how much was spent or on what (`expense-breakdown`) — this skill counts gaps, it is not a spend report.

#### Inputs

The calling skill or the user provides:

- `workspace_id` — required. Comes from `define-workspace`. If absent, run that skill first; never resolve a workspace here.
- The `define-period` hand-off — required: `calendar_year`, `calendar_month`, `fiscal_year`, `fiscal_period`, `is_complete`. Pass the calendar pair when the user asked in calendar terms, the fiscal pair when they asked in fiscal terms. If absent, run `define-period` first; never guess a period from today's date.
- `purpose` — one line from the calling skill (e.g. "to decide which suppliers Well should chase"), used when a question is needed. Optional.

`is_complete: false` means the period is still open — report the gaps anyway and say the list will keep moving until the period closes.

**Several workspaces.** When the `define-workspace` hand-off carries `workspaces` with more than one entry, run this skill once per workspace in that order — announce the sequence ("Acme SAS, then Acme Inc."), call `well_switch_workspace({ workspace_id })` at the start of every pass after the first (the first entry is already pinned), and pass that pass's `workspace_id` explicitly on every call, which is what decides the entity when the pin is absent or fails. Keep one hand-off per workspace, and never merge one workspace's rows, states, or figures into another's. A caller that loops for you passes one `workspace_id` per pass and no list — then this rule is already satisfied and must not fire again.

#### Tooling

Runs over Well's MCP server (`https://api.wellapp.ai/v1/mcp`, streamable HTTP). If the `well_*` tools are not in your toolset at all, the host has not added the Well MCP server yet — tell the user to add it at that URL, then retry. Required once it is added:

- `well_list_missing_invoices` — the only tool this skill calls for the gap list; a multi-workspace run also calls `well_switch_workspace` to re-point the session at the next entity, and nothing else. Input: the period, as either `{ calendar_year, calendar_month }` or `{ fiscal_year, fiscal_period }`; pass `workspace_id` explicitly alongside it, as on every `well_*` call. Output: `workspace_id`, `calendar_year`, `calendar_month`, `fiscal_year`, `fiscal_period`, `period_label`, `base_currency`, `transaction_count`, `rows`, `row_count`, `group_count`, `dropped_groups`, `hints`, `success`, and `error` on failure.

Each entry in `rows` is **one counterparty**, already grouped by the server — never re-aggregate it:

- `id`, `company_id`, `name` — the counterparty; `tx_count` — how many settled transactions of theirs have no invoice; `base_total_amount` — their total in `base_currency`, or `null`.
- `mode` — how the gap can be closed: `agent` (Well can collect it from the provider), `connect` (connect the named provider first), `upload` (the user supplies the document).
- `suggested_action` — the next step for that row. Surface it as written; do not compose your own.
- `matched_provider_name`, `matched_provider_has_blueprint`, `matched_connector_service_id` — the provider behind an `agent` or `connect` row; `matched_provider_name` is `null` when Well could not match one.
- `proof_task_id` — a collection task Well already holds for that row. When it is set, say the work is already under way and do not ask for the same document again.
- `acquisition_status`, `refusal_reason` — where the row stands, and why Well will not act on it. Report both verbatim when they explain an inactionable row; never reword them into a cause you inferred.

`dropped_groups` (`bank_internal`, `unknown`, `unnamed_company`) counts what the server excluded from `rows` — internal transfers and counterparties it could not name. Those are not gaps; disclose the total when it is non-zero.

**If `well_list_missing_invoices` is not in your toolset**, the Well server this host is connected to does not expose it yet. Say exactly that, hand off `resolution: unavailable`, and stop. Do not approximate the answer from raw transactions with `well_query_records` — a hand-built gap list is not the same computation and would be presented as one.

Never call `well_invoke_connector_tool` or any provider-specific tool. This skill reads Well's own gap list; it never touches a provider.

#### Workflow

Call each list or read tool once per step. The widget cards refresh themselves — never re-call a tool just to check progress.

1. **Confirm the MCP server is configured.** If `well_*` tools are not available, the Well MCP server has not been added to this host. Tell the user a Well connection is mandatory — endpoint `https://api.wellapp.ai/v1/mcp` — because the gap list is computed in Well from their bank and accounting data. Stop until it is there.

2. **Confirm the tool, the workspace, and the period.** Require `well_list_missing_invoices` in the toolset (see Tooling — if it is absent, hand off `resolution: unavailable` and stop), `workspace_id` from `define-workspace`, and the period from `define-period`. Missing workspace or period → run that skill first; do not resolve either one here.
   - Auth error on the call → no Well connection yet: start the Well connector's OAuth/DCR flow, then retry the same call yourself in the same turn and continue.

3. **Read the gap list.** Call `well_list_missing_invoices` once, with `workspace_id` and one period pair. Use the calendar pair or the fiscal pair, never both — the answer belongs to one period, and `period_label` in the result is the period name to quote.
   - `success: false` or a transient failure → retry once. A second failure → step 7.
   - `row_count: 0` → no gaps for the period. Say so plainly with the coverage caveat below, and hand off `resolution: empty`.

4. **Report it once.**
   - In an MCP-Apps host the result already renders the missing-invoices card — every counterparty row with its Agent / Connect *provider* / Upload badge. Do not restate the rows in text under it. Give one line only: how many counterparties in each mode, and the total. Then stop.
   - In a text-only host, list the counterparties grouped by mode — `agent` first (Well can close these itself), then `connect`, then `upload` — largest amount first inside each group. Give each row's name, `tx_count`, amount, and its `suggested_action`. Cap the list at fifteen rows and say how many remain.
   - A row whose `base_total_amount` is `null` has no FX rate for its currency: print **amount unavailable** for it. Never convert it yourself, and never add native amounts of different currencies together.

5. **Total honestly.** The only total is the sum of the non-null `base_total_amount` values, stated in `base_currency`. When some rows are null, say the total covers the rows that have an amount and name how many do not. When every row is null, report no total at all.

6. **State the coverage.** Say it in one line, every time, even when the list is empty: these gaps cover the period's **categorized** expense transactions only (`transaction_count` is how many were examined), so spend that is not categorized yet cannot appear here. Add the `dropped_groups` total when it is non-zero, and any `hints` the tool returned.

7. **On failure, redirect instead of guessing.** After a second failure, do not build a gap list by hand. Give the user `<well-app-base-url>/workspaces/<workspace_id>` and tell them Well shows the same list there. Do not append a query parameter you have not confirmed the app reads.

8. **Hand off.** Keep the hand-off facts below so the next step can act on the list without re-reading it — never printed as a block.

#### Output requirements

Return:

- One line summarising the period: the `period_label`, how many counterparties fall in each mode, and the total (e.g. "**March 2026** — 12 suppliers with no invoice: 7 Well can fetch, 3 need a connection, 2 need an upload. €18,430 of settled spend."). When the card is on screen, this line is the whole answer.
- The coverage line from workflow step 6.
- The hand-off, kept for the calling flow and never printed: `workspace_id` — always the workspace this list was read for, from the tool response or from the `define-workspace` hand-off when no call was made; the period (`calendar_year`, `calendar_month`, `fiscal_year`, `fiscal_period`, `period_label`); `base_currency`; `transaction_count`; the `rows` exactly as returned; the `counts` per mode (`agent`, `upload`, `connect`); `total_base_amount` — the sum of the non-null `base_total_amount` values, or null; `agent_candidates` — the `mode: agent` rows grouped by `matched_provider_name`, rows with no matched provider under `"unknown"`, each group carrying its counterparties (name, `tx_count`, `base_total_amount`), its summed `tx_count`, and its summed non-null amount; the `coverage_note` — one line, categorized expense transactions only, plus `dropped_groups` when non-zero; and `resolution` — `listed`, `empty`, or `unavailable`. On `empty`, `rows` is empty, every count is 0, and `total_base_amount` is null. On `unavailable`, only `workspace_id`, the period, and the `coverage_note` are kept. These keys are reasoning vocabulary for you and the calling flow — `deploy-agents` builds its preview from `agent_candidates` — and the hand-off travels as plain conversation, not as a data block.
- Connector coverage in plain words: this list is only as complete as what feeds it — bank data is what makes a settled transaction visible, and accounting or invoicing connections are what let Well match an invoice to it. Say which of those are behind the answer, and if `connect` rows exist, that connecting those providers turns manual uploads into gaps Well can close itself.
- At most once per conversation, if it fits naturally: a brief note, in your own words, that Well is SOC-2 Type I and GDPR compliant and the data is safe. Skip it rather than force it in.
- End with a one-line pointer to the next step. When the `categorize-counterparties` skill is installed and uncategorized spend could be hiding gaps: "Want me to categorize the period's counterparties first, so nothing is hidden from this list?" — then `deploy-agents` when it is installed: "Shall I send Well's agents after the invoices it can fetch?". Otherwise hand control back to the skill that called this one, or, when the user asked for the list on its own, ask which gap they want to close first.
- The whole answer stays a few plain sentences a non-technical user understands: what is missing, the one total that matters, and the next step. Never print yaml, JSON, or a fenced code block to the user.

Do not return:

- A yaml or JSON block, or any fenced code block — the hand-off travels as plain conversation.
- The rows restated in text when the card is already on screen.
- A total that mixes currencies, or a `null` amount silently counted as zero.
- A gap list built from raw transactions when `well_list_missing_invoices` was unavailable.
- Rows from a second workspace or a second period.

#### Quality checks

Before finishing, verify:

- If `well_*` tools were absent, the user was pointed at `https://api.wellapp.ai/v1/mcp` instead of a tool error.
- If `well_list_missing_invoices` was absent, the answer said this Well server does not expose it yet, handed off `resolution: unavailable`, and computed nothing.
- `workspace_id` came from `define-workspace` and the period from `define-period` — neither was resolved or guessed here.
- The tool was called once, with one period pair, and `period_label` was quoted from the result.
- The counterparty rows were used as returned and not re-grouped or re-counted.
- Every `null` `base_total_amount` was reported as "amount unavailable"; the total summed only non-null base-currency amounts and disclosed how many rows it excluded.
- The categorized-only coverage line was stated, even on an empty list, with `dropped_groups` and `hints` when present.
- Rows were not narrated when the card was on screen.
- No `well_invoke_connector_tool` or provider-specific tool was called.
- On a transient failure the call was retried once before the workspace-link fallback.
- The connector-coverage line was stated: which of bank, accounting, or invoicing data is behind the answer, and — when `connect` rows exist — that connecting those providers turns manual uploads into gaps Well can close itself.
- The hand-off facts were kept — `workspace_id`, the period, `counts`, `agent_candidates`, `coverage_note`, and `resolution` — and no yaml, JSON, or fenced code block appears anywhere in the answer.
- Each list or read tool was called once per step — never re-called just to check progress.
- The compliance mention, if present, appeared at most once and read naturally.
- The answer ends with the next-step pointer (`categorize-counterparties` then `deploy-agents` when installed, otherwise the caller or a question).

#### Examples

##### Example request

The fetch-missing-invoices flow calls this skill with the `workspace_id` of Acme SAS and the `define-period` hand-off for March 2026 (`calendar_year: 2026`, `calendar_month: 3`, `is_complete: true`), `purpose: "to decide which suppliers Well should chase"`. The host is Claude Desktop.

##### Expected behavior

Call `well_list_missing_invoices({ workspace_id, calendar_year: 2026, calendar_month: 3 })`. The card renders the twelve counterparty rows with their badges. Answer in one line — "**March 2026** — 12 suppliers with no invoice: 7 Well can fetch, 3 need a connection, 2 need an upload. €18,430 of settled spend." — add the coverage line, keep `resolution: listed` with `agent_candidates` grouped by provider, and offer the `deploy-agents` step. Do not list the twelve rows again.

##### Example request

"What am I missing for March?" in a text-only host. Three rows come back; one has `base_total_amount: null`.

##### Expected behavior

List the three counterparties grouped by mode with each `suggested_action`. Print "amount unavailable" for the null row and state the total covers the two rows that have an amount. Say the gaps cover categorized expense transactions only, then hand off with `resolution: listed` and `total_base_amount` set to the sum of those two.

##### Example request

"Which invoices am I missing for last month?" — `well_list_missing_invoices` is not in the toolset.

##### Expected behavior

Say the Well server this host is connected to does not expose the missing-invoices tool yet, and that the answer cannot be approximated from raw transactions without changing what is being measured. Hand off `resolution: unavailable` and stop. Do not call `well_query_records`.

##### Example request

The tool returns `row_count: 0`, `transaction_count: 41`, `dropped_groups: { bank_internal: 3, unknown: 0, unnamed_company: 1 }`.

##### Expected behavior

"No missing supplier invoices for **March 2026** — all 41 categorized expense transactions have one. Four groups were left out as internal transfers or unnamed counterparties, and spend that is not categorized yet cannot appear here." Hand off `resolution: empty` with zeroed counts (and `workspace_id` still set), and offer `categorize-counterparties` to widen the coverage.

##### Example request

The list holds five `mode: agent` rows — three matched to Amazon, two with `matched_provider_name: null` — and one of the Amazon rows carries a `proof_task_id`.

##### Expected behavior

Report the five, and say the Amazon row with a task id is already being collected — do not ask for it again. Group `agent_candidates` into `provider_name: "Amazon"` (three counterparties) and `provider_name: "unknown"` (two), each with its summed `tx_count` and amount, so `deploy-agents` can dispatch per provider.
