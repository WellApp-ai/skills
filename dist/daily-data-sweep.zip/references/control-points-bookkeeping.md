# Bookkeeping proof chain — BOOK-

Gate 6. Proof-of-payment, the disposition gap, company identity across the proof, the `confirmed` trap.

---

## SECOND FAMILY — bookkeeping proof-of-payment chain (`BOOK-`)

Runs after `BANK-`. Once a transaction is categorized it must carry a **proof of payment** —
normally an invoice — with the document attached, both counterparties identified, at least one of
them matching the transaction's own counterparty, e-invoicing-valid line items with VAT and FX,
and any banking details on the invoice linked to a real account or payment means.

### The governing principle: absence ≠ decision

**"No invoice found yet" and "no invoice is required" must never look identical in the data.**
Today they do — and that is the single most important gap in this family. A `not_required` /
`lost` disposition belongs **on the transaction**, so that a swept, decided transaction is
distinguishable from an unswept one. See § the disposition gap below.

### Measured baseline

Measured baseline (dated, re-probe before citing): [`baseline-2026-07-29.md`](baseline-2026-07-29.md).
No figure in that file is a standing fact; the numbers move day over day.

### The `confirmed` trap

`edge_status` defaults to `confirmed`, and `match_method` can be `llm_matched` **or**
`human_approved`. So an edge that is `confirmed` **and** `llm_matched` **and** carries no human actor
means *the model was confident* — **not** *a human verified it*. Any control point that treats
`confirmed` as reviewed — including the `RECON-provisional-match-backlog` check — reads **green while
reconciliation rests on unreviewed model output.** The sweep must therefore report
`confirmed AND llm_matched AND no human actor` as its own amber class, and the model needs a distinct
human-confirmation marker (see § Known limits — there is no audit-trail root).

Whether that condition currently holds for all, some, or none of the edges is a **measurement** —
read it from the baseline file, or re-probe. It is not a property of the schema.

### Schema constraints that shape this family

**The disposition cannot live on the link:** **`invoice_transactions.invoice_pk` is NOT NULL**, so
a row cannot exist to say *there is no invoice* — that would require a sentinel invoice, which is the
null-object anti-pattern and would corrupt every `invoices` aggregate and the AR/AP posting path.

The obligation to hold proof belongs to the **transaction**; the link is the *satisfaction* of
that obligation. So `proof_status` goes on `transactions`, and `invoice_transactions` stays purely
positive evidence — mirroring the `category_*` provenance pattern already on that entity
(`category_source` / `category_status` / `category_confidence`), so reviewers know the shape and
the CHECK-constraint precedent exists.

**`documents` CAN prove file integrity — the check is buildable today.**
`documents` has 20 columns including **`size` (NOT NULL)**, **`type` (NOT NULL, the MIME field)**,
and **`content_checksum`** (SHA-256 over *metadata-stripped* content — PDF `/Info`/dates/`/ID`
removed, JPEG APP/COM stripped, PNG text chunks stripped), plus `processing_status` /
`processing_stage` / `processing_error`. So zero-byte detection, wrong-MIME detection, and
*content-identity* duplicate detection are all expressible today. Because the checksum is
metadata-stripped, it catches **the same invoice re-uploaded under a different filename and used
to discharge a second obligation** — a duplicate-proof check, not merely an integrity one.

**`media` is NOT the document store** — `media_type` is `avatar | logo | banner` only, and it has
no size, MIME, or checksum. Any proof-of-payment check written against `media` is checking the
wrong table. All document integrity routes through `documents`.

**`transaction_documents` allows at most ONE active document per transaction** (partial unique on
`transaction_pk WHERE deleted_at IS NULL`). So "one transaction proving multiple invoices" must go
through multiple `invoice_transactions` edges — correct shape — but it also means a transaction
whose single slot holds a bank-statement PDF **cannot also hold the supplier invoice**.

**The `confirmed` trap, precisely.** `edge_status` is `confirmed | provisional` and **defaults to
`confirmed`** — and `provisional` is documented as the 0.55–0.85 review tier that is *"filtered
out of downstream pipes until a human confirms"*. Because `confirmed` is the default, a workspace in
which no edge carries `provisional` and none carries `match_method: human_approved` is a workspace
where **the review tier is not being used at all** — and that is what the baseline recorded. Measure
it, do not assume it. Proof-of-payment is a downstream pipe, so the correct floor is not a new
confidence number — it is honouring the existing contract: only `edge_status = 'confirmed'` counts as
proof, and a `provisional` edge must never satisfy it.

**A blocker on the duplicate-payment check.** `allocation_type` (`full | partial | overpayment |
fee_deduction`, default `full`) coexists with a **legacy `is_partial` boolean carrying a TODO to
remove it** — two fields encoding overlapping truth, able to disagree. Because both default to
"full/not-partial", a legacy instalment set is **indistinguishable from a duplicate payment**.
Retiring `is_partial` is the prerequisite for running the duplicate-payment check at the severity
it deserves (real money leaving twice).

### The disposition gap — a concrete schema proposal

`invoice_transactions` has 20 fields: `accounting_amount`, `accounting_currency`,
`allocation_type`, `amount`, `confidence`, `created_at`, `currency`, `deleted_at`, `edge_status`,
`exchange_rate_pk`, `invoice_pk`, `invoice_transaction_id`, `is_partial`, `match_method`, `pk`,
`reasoning`, `subscription_pk`, `transaction_pk`, `updated_at`, `workspace_pk`.

**None of them can express "no invoice required" or "invoice lost"** — and both FKs (`invoice_pk`,
`transaction_pk`) are structurally required for a row to exist at all, so a decision *about a
transaction with no invoice* has nowhere to live.

What the model needs, stated concretely:

- a **typed disposition** on the transaction side of the proof relation —
  `proof_status: matched | not_required | lost | pending` as an enum, plus
  `proof_status_reason` (free text) and `proof_status_set_by` / `proof_status_set_at` so a
  decision is attributable.
- It cannot live only on `invoice_transactions`, because the interesting cases have no invoice.
  Either add it to `transactions`, or allow a nullable `invoice_pk` on the link row.

Until it exists, `BOOK-txn-proof-decided` below is **unbuildable**, and the sweep can only report
gross "no proof link" counts without distinguishing a backlog from a completed judgement.

### `BOOK-` control points

Confirmed: `invoice_transactions` carries a **per-edge `amount` + `currency` + `accounting_amount`
+ `accounting_currency` + `exchange_rate_pk`** — so over-allocation and cross-currency match
checks ARE expressible.

#### Proof of payment

| id | name | bucket | check | fail signal | sev |
|---|---|---|---|---|---|
| `BOOK-txn-has-proof` | Categorized transaction has a proof link | complete | `transactions` with `category_key` non-null and no `invoice_transactions` row | any row past the grace window | red |
| `BOOK-txn-proof-decided` | Undecided vs decided-no-invoice | complete | **INCONCLUSIVE — no disposition field exists.** As specified: disposition enum ≠ null. Neither `transactions` nor `invoice_transactions` carries one (§ the disposition gap) | not evaluable — emit `INCONCLUSIVE`, never a colour | blocked |
| `BOOK-proof-not-required-misuse` | `not_required` on a row that needs one | complete | **INCONCLUSIVE — depends on the missing disposition field.** As specified: disposition `not_required` where `flow_kind`/`category_key` implies a supplier invoice | not evaluable — emit `INCONCLUSIVE`, never a colour | blocked |
| `BOOK-edge-not-human-confirmed` | Reconciliation is all model output | complete | `edge_status: confirmed` **and** `match_method: llm_matched` with no human actor | any edge | amber |
| `BOOK-edge-confidence-floor` | Low-confidence matches surfaced | complete | `confidence < 0.85` | any unreviewed | amber |
| `BOOK-edge-amount-agrees` | Edge amount matches the invoice | complete | `allocation_type: full` and abs(`amount` − invoice `grand_total`) > tolerance §14 | any | red |
| `BOOK-edge-overallocated` | Allocations exceed the invoice | complete | sum of live edge `amount` per `invoice_pk` > `grand_total` + tolerance | any | red |
| `BOOK-edge-currency-consistent` | Cross-currency edge has a rate | complete | edge `currency` ≠ invoice `local_currency` and `exchange_rate_pk IS NULL` | any | red |
| `BOOK-edge-dangling` | Edge points at a dead row | complete | `invoice_pk` or `transaction_pk` resolving to absent/soft-deleted | any | red |

**Removed: `BOOK-proof-lost-trend`** (`lost` share rising, sweep over sweep). Deleted rather than
marked blocked. **Every sweep run is cold** — the MCP is read-only and exposes no output root, so no
prior-sweep state exists or can be written, and a cross-run comparison can never fire. Holding it as
a permanent `INCONCLUSIVE` would be worse than removing it: a check that returns the same
INCONCLUSIVE forever is indistinguishable from a disabled one, and it inflates the not-evaluated
count that stamps `(partial — N not evaluated)` on a bucket verdict — making a fully-checked month
read as degraded. It is named here because this skill's rule is that a check it cannot make is
declared, never silently dropped. A trend on `lost` becomes buildable only once both a disposition
field (§ the disposition gap) and a sweep-result store exist.

#### Company identity across the proof

| id | name | bucket | check | fail signal | sev |
|---|---|---|---|---|---|
| `BOOK-invoice-both-parties` | Issuer and receiver both identified | complete | `invoices.issuer_pk` or `receiver_pk` null | any row | red |
| `BOOK-invoice-core-fields` | complete | Invoices carry the fields the skills read | `invoices` where any of `grand_total` / `local_currency` / `issue_date` / `due_date` `_is_null` | any row | red | accounts-receivable-aging, bills-due, rank-clients-by-ltv |
| `BOOK-party-matches-txn-counterparty` | One invoice side IS the transaction's counterparty | complete | resolve txn counterparty via `debtor_/creditor_payment_means` → `payment_means.company_pk`; assert it equals `issuer_pk` **or** `receiver_pk`. **Rows whose counterparty does not resolve are excluded and returned as `INCONCLUSIVE`, never as pass** — they are counted by `BOOK-party-match-unverifiable` | neither side matches, on a row where the counterparty *did* resolve | red |
| `BOOK-party-match-unverifiable` | Size of the population the above cannot judge | complete | txn counterparty null. This control point **is** evaluable — it counts the unevaluable rows; it is the check above that returns `INCONCLUSIVE` for them | any row | red |

#### Document attachment

| id | name | bucket | check | fail signal | sev |
|---|---|---|---|---|---|
| `BOOK-invoice-has-document` | Document attached | complete | `invoices.document_pk IS NULL` | any row past the grace window (`DOC-` tolerances) | red |
| `BOOK-document-resolves` | Not a phantom attachment | complete | `document_pk` non-null resolving to absent/soft-deleted | any | red |
| `BOOK-document-has-content` | File is **recorded**, not a 0-byte placeholder | complete | `documents.size < 1024` or `content_checksum IS NULL`. A green here means "content recorded", **never** "file retrievable" — `bucket`/`path` are unvalidated strings (see `control-points-documents.md`) | any row | red |
| `BOOK-document-right-kind` | Mime is a document kind that can be a receipt | complete | **typed exact-match allow-list of mime types — never a substring test on a filename**; reuse the existing `ACCEPTED_DOCUMENT_FORMATS` const rather than inventing a second list | any outside the list | amber |
| `BOOK-document-tenancy` | Document belongs to this workspace | exhaustive | document's workspace ≠ invoice's workspace | any | red |
